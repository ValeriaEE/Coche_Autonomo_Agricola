
;CodeVisionAVR C Compiler V4.06a Evaluation
;(C) Copyright 1998-2025 Pavel Haiduc, HP InfoTech S.R.L.
;http://www.hpinfotech.ro

;Build configuration    : Debug
;Chip type              : ATmega328P
;Program type           : Application
;Clock frequency        : 1.000000 MHz
;Memory model           : Small
;Optimize for           : Size
;(s)printf features     : int, width
;(s)scanf features      : int, width
;External RAM size      : 0
;Data Stack size        : 512 byte(s)
;Heap size              : 0 byte(s)
;Promote 'char' to 'int': Yes
;'char' is unsigned     : Yes
;8 bit enums            : Yes
;Global 'const' stored in FLASH: No
;Enhanced function parameter passing: Mode 2
;Enhanced core instructions: On
;Automatic register allocation for global variables: Off
;Smart register allocation: Off

	#define _MODEL_SMALL_

	#pragma AVRPART ADMIN PART_NAME ATmega328P
	#pragma AVRPART MEMORY PROG_FLASH 32768
	#pragma AVRPART MEMORY EEPROM 1024
	#pragma AVRPART MEMORY INT_SRAM SIZE 2048
	#pragma AVRPART MEMORY INT_SRAM START_ADDR 0x100

	#define CALL_SUPPORTED 1

	.LISTMAC

	.EQU EERE=0x0
	.EQU EEWE=0x1
	.EQU EEMWE=0x2
	.EQU UDRE=0x5
	.EQU RXC=0x7
	.EQU EECR=0x1F
	.EQU EEDR=0x20
	.EQU EEARL=0x21
	.EQU EEARH=0x22
	.EQU SPSR=0x2D
	.EQU SPDR=0x2E
	.EQU SMCR=0x33
	.EQU MCUSR=0x34
	.EQU MCUCR=0x35
	.EQU WDTCSR=0x60
	.EQU UCSR0A=0xC0
	.EQU UDR0=0xC6
	.EQU SPMCSR=0x37
	.EQU SPL=0x3D
	.EQU SPH=0x3E
	.EQU SREG=0x3F
	.EQU GPIOR0=0x1E

	.DEF R0X0=R0
	.DEF R0X1=R1
	.DEF R0X2=R2
	.DEF R0X3=R3
	.DEF R0X4=R4
	.DEF R0X5=R5
	.DEF R0X6=R6
	.DEF R0X7=R7
	.DEF R0X8=R8
	.DEF R0X9=R9
	.DEF R0XA=R10
	.DEF R0XB=R11
	.DEF R0XC=R12
	.DEF R0XD=R13
	.DEF R0XE=R14
	.DEF R0XF=R15
	.DEF R0X10=R16
	.DEF R0X11=R17
	.DEF R0X12=R18
	.DEF R0X13=R19
	.DEF R0X14=R20
	.DEF R0X15=R21
	.DEF R0X16=R22
	.DEF R0X17=R23
	.DEF R0X18=R24
	.DEF R0X19=R25
	.DEF R0X1A=R26
	.DEF R0X1B=R27
	.DEF R0X1C=R28
	.DEF R0X1D=R29
	.DEF R0X1E=R30
	.DEF R0X1F=R31

	.EQU __SRAM_START=0x0100
	.EQU __SRAM_END=0x08FF
	.EQU __DSTACK_SIZE=0x0200
	.EQU __HEAP_SIZE=0x0000
	.EQU __CLEAR_SRAM_SIZE=__SRAM_END-__SRAM_START+1

	.EQU __FLASH_PAGE_SIZE=0x40
	.EQU __EEPROM_PAGE_SIZE=0x04

	.MACRO __CPD1N
	CPI  R30,LOW(@0)
	LDI  R26,HIGH(@0)
	CPC  R31,R26
	LDI  R26,BYTE3(@0)
	CPC  R22,R26
	LDI  R26,BYTE4(@0)
	CPC  R23,R26
	.ENDM

	.MACRO __CPD2N
	CPI  R26,LOW(@0)
	LDI  R30,HIGH(@0)
	CPC  R27,R30
	LDI  R30,BYTE3(@0)
	CPC  R24,R30
	LDI  R30,BYTE4(@0)
	CPC  R25,R30
	.ENDM

	.MACRO __CPWRR
	CP   R@0,R@2
	CPC  R@1,R@3
	.ENDM

	.MACRO __CPWRN
	CPI  R@0,LOW(@2)
	LDI  R30,HIGH(@2)
	CPC  R@1,R30
	.ENDM

	.MACRO __ADDB1MN
	SUBI R30,LOW(-@0-(@1))
	.ENDM

	.MACRO __ADDB2MN
	SUBI R26,LOW(-@0-(@1))
	.ENDM

	.MACRO __ADDW1MN
	SUBI R30,LOW(-@0-(@1))
	SBCI R31,HIGH(-@0-(@1))
	.ENDM

	.MACRO __ADDW2MN
	SUBI R26,LOW(-@0-(@1))
	SBCI R27,HIGH(-@0-(@1))
	.ENDM

	.MACRO __ADDW1FN
	SUBI R30,LOW(-2*@0-(@1))
	SBCI R31,HIGH(-2*@0-(@1))
	.ENDM

	.MACRO __ADDD1FN
	SUBI R30,LOW(-2*@0-(@1))
	SBCI R31,HIGH(-2*@0-(@1))
	SBCI R22,BYTE3(-2*@0-(@1))
	.ENDM

	.MACRO __ADDD1N
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	SBCI R22,BYTE3(-@0)
	SBCI R23,BYTE4(-@0)
	.ENDM

	.MACRO __ADDD2N
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	SBCI R24,BYTE3(-@0)
	SBCI R25,BYTE4(-@0)
	.ENDM

	.MACRO __SUBD1N
	SUBI R30,LOW(@0)
	SBCI R31,HIGH(@0)
	SBCI R22,BYTE3(@0)
	SBCI R23,BYTE4(@0)
	.ENDM

	.MACRO __SUBD2N
	SUBI R26,LOW(@0)
	SBCI R27,HIGH(@0)
	SBCI R24,BYTE3(@0)
	SBCI R25,BYTE4(@0)
	.ENDM

	.MACRO __ANDBMNN
	LDS  R30,@0+(@1)
	ANDI R30,LOW(@2)
	STS  @0+(@1),R30
	.ENDM

	.MACRO __ANDWMNN
	LDS  R30,@0+(@1)
	ANDI R30,LOW(@2)
	STS  @0+(@1),R30
	LDS  R30,@0+(@1)+1
	ANDI R30,HIGH(@2)
	STS  @0+(@1)+1,R30
	.ENDM

	.MACRO __ANDD1N
	ANDI R30,LOW(@0)
	ANDI R31,HIGH(@0)
	ANDI R22,BYTE3(@0)
	ANDI R23,BYTE4(@0)
	.ENDM

	.MACRO __ANDD2N
	ANDI R26,LOW(@0)
	ANDI R27,HIGH(@0)
	ANDI R24,BYTE3(@0)
	ANDI R25,BYTE4(@0)
	.ENDM

	.MACRO __ORBMNN
	LDS  R30,@0+(@1)
	ORI  R30,LOW(@2)
	STS  @0+(@1),R30
	.ENDM

	.MACRO __ORWMNN
	LDS  R30,@0+(@1)
	ORI  R30,LOW(@2)
	STS  @0+(@1),R30
	LDS  R30,@0+(@1)+1
	ORI  R30,HIGH(@2)
	STS  @0+(@1)+1,R30
	.ENDM

	.MACRO __ORD1N
	ORI  R30,LOW(@0)
	ORI  R31,HIGH(@0)
	ORI  R22,BYTE3(@0)
	ORI  R23,BYTE4(@0)
	.ENDM

	.MACRO __ORD2N
	ORI  R26,LOW(@0)
	ORI  R27,HIGH(@0)
	ORI  R24,BYTE3(@0)
	ORI  R25,BYTE4(@0)
	.ENDM

	.MACRO __DELAY_USB
	LDI  R24,LOW(@0)
__DELAY_USB_LOOP:
	DEC  R24
	BRNE __DELAY_USB_LOOP
	.ENDM

	.MACRO __DELAY_USW
	LDI  R24,LOW(@0)
	LDI  R25,HIGH(@0)
__DELAY_USW_LOOP:
	SBIW R24,1
	BRNE __DELAY_USW_LOOP
	.ENDM

	.MACRO __GETW1P
	LD   R30,X+
	LD   R31,X
	SBIW R26,1
	.ENDM

	.MACRO __GETD1S
	LDD  R30,Y+@0
	LDD  R31,Y+@0+1
	LDD  R22,Y+@0+2
	LDD  R23,Y+@0+3
	.ENDM

	.MACRO __GETD2S
	LDD  R26,Y+@0
	LDD  R27,Y+@0+1
	LDD  R24,Y+@0+2
	LDD  R25,Y+@0+3
	.ENDM

	.MACRO __GETD1P_INC
	LD   R30,X+
	LD   R31,X+
	LD   R22,X+
	LD   R23,X+
	.ENDM

	.MACRO __GETD1P_DEC
	LD   R23,-X
	LD   R22,-X
	LD   R31,-X
	LD   R30,-X
	.ENDM

	.MACRO __PUTDP1
	ST   X+,R30
	ST   X+,R31
	ST   X+,R22
	ST   X,R23
	.ENDM

	.MACRO __PUTDP1_DEC
	ST   -X,R23
	ST   -X,R22
	ST   -X,R31
	ST   -X,R30
	.ENDM

	.MACRO __PUTD1S
	STD  Y+@0,R30
	STD  Y+@0+1,R31
	STD  Y+@0+2,R22
	STD  Y+@0+3,R23
	.ENDM

	.MACRO __PUTD2S
	STD  Y+@0,R26
	STD  Y+@0+1,R27
	STD  Y+@0+2,R24
	STD  Y+@0+3,R25
	.ENDM

	.MACRO __PUTDZ2
	STD  Z+@0,R26
	STD  Z+@0+1,R27
	STD  Z+@0+2,R24
	STD  Z+@0+3,R25
	.ENDM

	.MACRO __CLRD1S
	STD  Y+@0,R30
	STD  Y+@0+1,R30
	STD  Y+@0+2,R30
	STD  Y+@0+3,R30
	.ENDM

	.MACRO __CPD10
	SBIW R30,0
	SBCI R22,0
	SBCI R23,0
	.ENDM

	.MACRO __CPD20
	SBIW R26,0
	SBCI R24,0
	SBCI R25,0
	.ENDM

	.MACRO __ADDD12
	ADD  R30,R26
	ADC  R31,R27
	ADC  R22,R24
	ADC  R23,R25
	.ENDM

	.MACRO __ADDD21
	ADD  R26,R30
	ADC  R27,R31
	ADC  R24,R22
	ADC  R25,R23
	.ENDM

	.MACRO __SUBD12
	SUB  R30,R26
	SBC  R31,R27
	SBC  R22,R24
	SBC  R23,R25
	.ENDM

	.MACRO __SUBD21
	SUB  R26,R30
	SBC  R27,R31
	SBC  R24,R22
	SBC  R25,R23
	.ENDM

	.MACRO __ANDD12
	AND  R30,R26
	AND  R31,R27
	AND  R22,R24
	AND  R23,R25
	.ENDM

	.MACRO __ORD12
	OR   R30,R26
	OR   R31,R27
	OR   R22,R24
	OR   R23,R25
	.ENDM

	.MACRO __XORD12
	EOR  R30,R26
	EOR  R31,R27
	EOR  R22,R24
	EOR  R23,R25
	.ENDM

	.MACRO __XORD21
	EOR  R26,R30
	EOR  R27,R31
	EOR  R24,R22
	EOR  R25,R23
	.ENDM

	.MACRO __COMD1
	COM  R30
	COM  R31
	COM  R22
	COM  R23
	.ENDM

	.MACRO __MULD2_2
	LSL  R26
	ROL  R27
	ROL  R24
	ROL  R25
	.ENDM

	.MACRO __LSRD1
	LSR  R23
	ROR  R22
	ROR  R31
	ROR  R30
	.ENDM

	.MACRO __LSLD1
	LSL  R30
	ROL  R31
	ROL  R22
	ROL  R23
	.ENDM

	.MACRO __ASRB4
	ASR  R30
	ASR  R30
	ASR  R30
	ASR  R30
	.ENDM

	.MACRO __ASRW8
	MOV  R30,R31
	CLR  R31
	SBRC R30,7
	SER  R31
	.ENDM

	.MACRO __LSRD16
	MOV  R30,R22
	MOV  R31,R23
	LDI  R22,0
	LDI  R23,0
	.ENDM

	.MACRO __LSLD16
	MOV  R22,R30
	MOV  R23,R31
	LDI  R30,0
	LDI  R31,0
	.ENDM

	.MACRO __CWD1
	MOV  R22,R31
	ADD  R22,R22
	SBC  R22,R22
	MOV  R23,R22
	.ENDM

	.MACRO __CWD2
	MOV  R24,R27
	ADD  R24,R24
	SBC  R24,R24
	MOV  R25,R24
	.ENDM

	.MACRO __SETMSD1
	SER  R31
	SER  R22
	SER  R23
	.ENDM

	.MACRO __ADDW1R15
	CLR  R0
	ADD  R30,R15
	ADC  R31,R0
	.ENDM

	.MACRO __ADDW2R15
	CLR  R0
	ADD  R26,R15
	ADC  R27,R0
	.ENDM

	.MACRO __EQB12
	CP   R30,R26
	LDI  R30,1
	BREQ PC+2
	CLR  R30
	.ENDM

	.MACRO __NEB12
	CP   R30,R26
	LDI  R30,1
	BRNE PC+2
	CLR  R30
	.ENDM

	.MACRO __LEB12
	CP   R30,R26
	LDI  R30,1
	BRGE PC+2
	CLR  R30
	.ENDM

	.MACRO __GEB12
	CP   R26,R30
	LDI  R30,1
	BRGE PC+2
	CLR  R30
	.ENDM

	.MACRO __LTB12
	CP   R26,R30
	LDI  R30,1
	BRLT PC+2
	CLR  R30
	.ENDM

	.MACRO __GTB12
	CP   R30,R26
	LDI  R30,1
	BRLT PC+2
	CLR  R30
	.ENDM

	.MACRO __LEB12U
	CP   R30,R26
	LDI  R30,1
	BRSH PC+2
	CLR  R30
	.ENDM

	.MACRO __GEB12U
	CP   R26,R30
	LDI  R30,1
	BRSH PC+2
	CLR  R30
	.ENDM

	.MACRO __LTB12U
	CP   R26,R30
	LDI  R30,1
	BRLO PC+2
	CLR  R30
	.ENDM

	.MACRO __GTB12U
	CP   R30,R26
	LDI  R30,1
	BRLO PC+2
	CLR  R30
	.ENDM

	.MACRO __CPW01
	CLR  R0
	CP   R0,R30
	CPC  R0,R31
	.ENDM

	.MACRO __CPW02
	CLR  R0
	CP   R0,R26
	CPC  R0,R27
	.ENDM

	.MACRO __CPD12
	CP   R30,R26
	CPC  R31,R27
	CPC  R22,R24
	CPC  R23,R25
	.ENDM

	.MACRO __CPD21
	CP   R26,R30
	CPC  R27,R31
	CPC  R24,R22
	CPC  R25,R23
	.ENDM

	.MACRO __BSTB1
	CLT
	TST  R30
	BREQ PC+2
	SET
	.ENDM

	.MACRO __LNEGB1
	TST  R30
	LDI  R30,1
	BREQ PC+2
	CLR  R30
	.ENDM

	.MACRO __LNEGW1
	OR   R30,R31
	LDI  R30,1
	BREQ PC+2
	LDI  R30,0
	.ENDM

	.MACRO __POINTB1MN
	LDI  R30,LOW(@0+(@1))
	.ENDM

	.MACRO __POINTW1MN
	LDI  R30,LOW(@0+(@1))
	LDI  R31,HIGH(@0+(@1))
	.ENDM

	.MACRO __POINTD1M
	LDI  R30,LOW(@0)
	LDI  R31,HIGH(@0)
	LDI  R22,BYTE3(@0)
	LDI  R23,BYTE4(@0)
	.ENDM

	.MACRO __POINTW1FN
	LDI  R30,LOW(2*@0+(@1))
	LDI  R31,HIGH(2*@0+(@1))
	.ENDM

	.MACRO __POINTD1FN
	LDI  R30,LOW(2*@0+(@1))
	LDI  R31,HIGH(2*@0+(@1))
	LDI  R22,BYTE3(2*@0+(@1))
	LDI  R23,BYTE4(2*@0+(@1))
	.ENDM

	.MACRO __POINTB2MN
	LDI  R26,LOW(@0+(@1))
	.ENDM

	.MACRO __POINTW2MN
	LDI  R26,LOW(@0+(@1))
	LDI  R27,HIGH(@0+(@1))
	.ENDM

	.MACRO __POINTD2M
	LDI  R26,LOW(@0)
	LDI  R27,HIGH(@0)
	LDI  R24,BYTE3(@0)
	LDI  R25,BYTE4(@0)
	.ENDM

	.MACRO __POINTW2FN
	LDI  R26,LOW(2*@0+(@1))
	LDI  R27,HIGH(2*@0+(@1))
	.ENDM

	.MACRO __POINTD2FN
	LDI  R26,LOW(2*@0+(@1))
	LDI  R27,HIGH(2*@0+(@1))
	LDI  R24,BYTE3(2*@0+(@1))
	LDI  R25,BYTE4(2*@0+(@1))
	.ENDM

	.MACRO __POINTBRM
	LDI  R@0,LOW(@1)
	.ENDM

	.MACRO __POINTWRM
	LDI  R@0,LOW(@2)
	LDI  R@1,HIGH(@2)
	.ENDM

	.MACRO __POINTBRMN
	LDI  R@0,LOW(@1+(@2))
	.ENDM

	.MACRO __POINTWRMN
	LDI  R@0,LOW(@2+(@3))
	LDI  R@1,HIGH(@2+(@3))
	.ENDM

	.MACRO __POINTWRFN
	LDI  R@0,LOW(@2*2+(@3))
	LDI  R@1,HIGH(@2*2+(@3))
	.ENDM

	.MACRO __GETD1N
	LDI  R30,LOW(@0)
	LDI  R31,HIGH(@0)
	LDI  R22,BYTE3(@0)
	LDI  R23,BYTE4(@0)
	.ENDM

	.MACRO __GETD2N
	LDI  R26,LOW(@0)
	LDI  R27,HIGH(@0)
	LDI  R24,BYTE3(@0)
	LDI  R25,BYTE4(@0)
	.ENDM

	.MACRO __GETB1MN
	LDS  R30,@0+(@1)
	.ENDM

	.MACRO __GETB1HMN
	LDS  R31,@0+(@1)
	.ENDM

	.MACRO __GETW1MN
	LDS  R30,@0+(@1)
	LDS  R31,@0+(@1)+1
	.ENDM

	.MACRO __GETD1MN
	LDS  R30,@0+(@1)
	LDS  R31,@0+(@1)+1
	LDS  R22,@0+(@1)+2
	LDS  R23,@0+(@1)+3
	.ENDM

	.MACRO __GETBRMN
	LDS  R@0,@1+(@2)
	.ENDM

	.MACRO __GETWRMN
	LDS  R@0,@2+(@3)
	LDS  R@1,@2+(@3)+1
	.ENDM

	.MACRO __GETWRZ
	LDD  R@0,Z+@2
	LDD  R@1,Z+@2+1
	.ENDM

	.MACRO __GETD2Z
	LDD  R26,Z+@0
	LDD  R27,Z+@0+1
	LDD  R24,Z+@0+2
	LDD  R25,Z+@0+3
	.ENDM

	.MACRO __GETB2MN
	LDS  R26,@0+(@1)
	.ENDM

	.MACRO __GETW2MN
	LDS  R26,@0+(@1)
	LDS  R27,@0+(@1)+1
	.ENDM

	.MACRO __GETD2MN
	LDS  R26,@0+(@1)
	LDS  R27,@0+(@1)+1
	LDS  R24,@0+(@1)+2
	LDS  R25,@0+(@1)+3
	.ENDM

	.MACRO __PUTB1MN
	STS  @0+(@1),R30
	.ENDM

	.MACRO __PUTW1MN
	STS  @0+(@1),R30
	STS  @0+(@1)+1,R31
	.ENDM

	.MACRO __PUTD1MN
	STS  @0+(@1),R30
	STS  @0+(@1)+1,R31
	STS  @0+(@1)+2,R22
	STS  @0+(@1)+3,R23
	.ENDM

	.MACRO __PUTB1EN
	LDI  R26,LOW(@0+(@1))
	LDI  R27,HIGH(@0+(@1))
	CALL __EEPROMWRB
	.ENDM

	.MACRO __PUTW1EN
	LDI  R26,LOW(@0+(@1))
	LDI  R27,HIGH(@0+(@1))
	CALL __EEPROMWRW
	.ENDM

	.MACRO __PUTD1EN
	LDI  R26,LOW(@0+(@1))
	LDI  R27,HIGH(@0+(@1))
	CALL __EEPROMWRD
	.ENDM

	.MACRO __PUTBR0MN
	STS  @0+(@1),R0
	.ENDM

	.MACRO __PUTBMRN
	STS  @0+(@1),R@2
	.ENDM

	.MACRO __PUTWMRN
	STS  @0+(@1),R@2
	STS  @0+(@1)+1,R@3
	.ENDM

	.MACRO __PUTBZR
	STD  Z+@1,R@0
	.ENDM

	.MACRO __PUTWZR
	STD  Z+@2,R@0
	STD  Z+@2+1,R@1
	.ENDM

	.MACRO __GETW1R
	MOV  R30,R@0
	MOV  R31,R@1
	.ENDM

	.MACRO __GETW2R
	MOV  R26,R@0
	MOV  R27,R@1
	.ENDM

	.MACRO __GETWRN
	LDI  R@0,LOW(@2)
	LDI  R@1,HIGH(@2)
	.ENDM

	.MACRO __PUTW1R
	MOV  R@0,R30
	MOV  R@1,R31
	.ENDM

	.MACRO __PUTW2R
	MOV  R@0,R26
	MOV  R@1,R27
	.ENDM

	.MACRO __ADDWRN
	SUBI R@0,LOW(-@2)
	SBCI R@1,HIGH(-@2)
	.ENDM

	.MACRO __ADDWRR
	ADD  R@0,R@2
	ADC  R@1,R@3
	.ENDM

	.MACRO __SUBWRN
	SUBI R@0,LOW(@2)
	SBCI R@1,HIGH(@2)
	.ENDM

	.MACRO __SUBWRR
	SUB  R@0,R@2
	SBC  R@1,R@3
	.ENDM

	.MACRO __ANDWRN
	ANDI R@0,LOW(@2)
	ANDI R@1,HIGH(@2)
	.ENDM

	.MACRO __ANDWRR
	AND  R@0,R@2
	AND  R@1,R@3
	.ENDM

	.MACRO __ORWRN
	ORI  R@0,LOW(@2)
	ORI  R@1,HIGH(@2)
	.ENDM

	.MACRO __ORWRR
	OR   R@0,R@2
	OR   R@1,R@3
	.ENDM

	.MACRO __EORWRR
	EOR  R@0,R@2
	EOR  R@1,R@3
	.ENDM

	.MACRO __GETWRS
	LDD  R@0,Y+@2
	LDD  R@1,Y+@2+1
	.ENDM

	.MACRO __PUTBSR
	STD  Y+@1,R@0
	.ENDM

	.MACRO __PUTWSR
	STD  Y+@2,R@0
	STD  Y+@2+1,R@1
	.ENDM

	.MACRO __MOVEWRR
	MOV  R@0,R@2
	MOV  R@1,R@3
	.ENDM

	.MACRO __INWR
	IN   R@0,@2
	IN   R@1,@2+1
	.ENDM

	.MACRO __OUTWR
	OUT  @2+1,R@1
	OUT  @2,R@0
	.ENDM

	.MACRO __CALL1MN
	LDS  R30,@0+(@1)
	LDS  R31,@0+(@1)+1
	ICALL
	.ENDM

	.MACRO __CALL1FN
	LDI  R30,LOW(2*@0+(@1))
	LDI  R31,HIGH(2*@0+(@1))
	CALL __GETW1PF
	ICALL
	.ENDM

	.MACRO __CALL2EN
	PUSH R26
	PUSH R27
	LDI  R26,LOW(@0+(@1))
	LDI  R27,HIGH(@0+(@1))
	CALL __EEPROMRDW
	POP  R27
	POP  R26
	ICALL
	.ENDM

	.MACRO __CALL2EX
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	CALL __EEPROMRDD
	ICALL
	.ENDM

	.MACRO __GETW1STACK
	IN   R30,SPL
	IN   R31,SPH
	ADIW R30,@0+1
	LD   R0,Z+
	LD   R31,Z
	MOV  R30,R0
	.ENDM

	.MACRO __GETD1STACK
	IN   R30,SPL
	IN   R31,SPH
	ADIW R30,@0+1
	LD   R0,Z+
	LD   R1,Z+
	LD   R22,Z
	MOVW R30,R0
	.ENDM

	.MACRO __NBST
	BST  R@0,@1
	IN   R30,SREG
	LDI  R31,0x40
	EOR  R30,R31
	OUT  SREG,R30
	.ENDM


	.MACRO __PUTB1SN
	LDD  R26,Y+@0
	LDD  R27,Y+@0+1
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X,R30
	.ENDM

	.MACRO __PUTW1SN
	LDD  R26,Y+@0
	LDD  R27,Y+@0+1
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1SN
	LDD  R26,Y+@0
	LDD  R27,Y+@0+1
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X+,R30
	ST   X+,R31
	ST   X+,R22
	ST   X,R23
	.ENDM

	.MACRO __PUTB1SNS
	LDD  R26,Y+@0
	LDD  R27,Y+@0+1
	ADIW R26,@1
	ST   X,R30
	.ENDM

	.MACRO __PUTW1SNS
	LDD  R26,Y+@0
	LDD  R27,Y+@0+1
	ADIW R26,@1
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1SNS
	LDD  R26,Y+@0
	LDD  R27,Y+@0+1
	ADIW R26,@1
	ST   X+,R30
	ST   X+,R31
	ST   X+,R22
	ST   X,R23
	.ENDM

	.MACRO __PUTB1PMN
	LDS  R26,@0
	LDS  R27,@0+1
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X,R30
	.ENDM

	.MACRO __PUTW1PMN
	LDS  R26,@0
	LDS  R27,@0+1
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1PMN
	LDS  R26,@0
	LDS  R27,@0+1
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X+,R30
	ST   X+,R31
	ST   X+,R22
	ST   X,R23
	.ENDM

	.MACRO __PUTB1PMNS
	LDS  R26,@0
	LDS  R27,@0+1
	ADIW R26,@1
	ST   X,R30
	.ENDM

	.MACRO __PUTW1PMNS
	LDS  R26,@0
	LDS  R27,@0+1
	ADIW R26,@1
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1PMNS
	LDS  R26,@0
	LDS  R27,@0+1
	ADIW R26,@1
	ST   X+,R30
	ST   X+,R31
	ST   X+,R22
	ST   X,R23
	.ENDM

	.MACRO __PUTB1RN
	MOVW R26,R@0
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X,R30
	.ENDM

	.MACRO __PUTW1RN
	MOVW R26,R@0
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1RN
	MOVW R26,R@0
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X+,R30
	ST   X+,R31
	ST   X+,R22
	ST   X,R23
	.ENDM

	.MACRO __PUTB1RNS
	MOVW R26,R@0
	ADIW R26,@1
	ST   X,R30
	.ENDM

	.MACRO __PUTW1RNS
	MOVW R26,R@0
	ADIW R26,@1
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1RNS
	MOVW R26,R@0
	ADIW R26,@1
	ST   X+,R30
	ST   X+,R31
	ST   X+,R22
	ST   X,R23
	.ENDM

	.MACRO __PUTB1RON
	MOV  R26,R@0
	MOV  R27,R@1
	SUBI R26,LOW(-@2)
	SBCI R27,HIGH(-@2)
	ST   X,R30
	.ENDM

	.MACRO __PUTW1RON
	MOV  R26,R@0
	MOV  R27,R@1
	SUBI R26,LOW(-@2)
	SBCI R27,HIGH(-@2)
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1RON
	MOV  R26,R@0
	MOV  R27,R@1
	SUBI R26,LOW(-@2)
	SBCI R27,HIGH(-@2)
	ST   X+,R30
	ST   X+,R31
	ST   X+,R22
	ST   X,R23
	.ENDM

	.MACRO __PUTB1RONS
	MOV  R26,R@0
	MOV  R27,R@1
	ADIW R26,@2
	ST   X,R30
	.ENDM

	.MACRO __PUTW1RONS
	MOV  R26,R@0
	MOV  R27,R@1
	ADIW R26,@2
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1RONS
	MOV  R26,R@0
	MOV  R27,R@1
	ADIW R26,@2
	ST   X+,R30
	ST   X+,R31
	ST   X+,R22
	ST   X,R23
	.ENDM


	.MACRO __GETB1SX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	LD   R30,Z
	.ENDM

	.MACRO __GETB1HSX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	LD   R31,Z
	.ENDM

	.MACRO __GETW1SX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	CALL __GETW1Z
	.ENDM

	.MACRO __GETD1SX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	CALL __GETD1Z
	.ENDM

	.MACRO __GETB2SX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	LD   R26,X
	.ENDM

	.MACRO __GETW2SX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	CALL __GETW2X
	.ENDM

	.MACRO __GETD2SX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	CALL __GETD2X
	.ENDM

	.MACRO __GETBRSX
	MOVW R30,R28
	SUBI R30,LOW(-@1)
	SBCI R31,HIGH(-@1)
	LD   R@0,Z
	.ENDM

	.MACRO __GETWRSX
	MOVW R30,R28
	SUBI R30,LOW(-@2)
	SBCI R31,HIGH(-@2)
	LD   R@0,Z+
	LD   R@1,Z
	.ENDM

	.MACRO __GETBRSX2
	MOVW R26,R28
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	LD   R@0,X
	.ENDM

	.MACRO __GETWRSX2
	MOVW R26,R28
	SUBI R26,LOW(-@2)
	SBCI R27,HIGH(-@2)
	LD   R@0,X+
	LD   R@1,X
	.ENDM

	.MACRO __LSLW8SX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	LD   R31,Z
	CLR  R30
	.ENDM

	.MACRO __PUTB1SX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	ST   X,R30
	.ENDM

	.MACRO __PUTW1SX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1SX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	ST   X+,R30
	ST   X+,R31
	ST   X+,R22
	ST   X,R23
	.ENDM

	.MACRO __CLRW1SX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	ST   X+,R30
	ST   X,R30
	.ENDM

	.MACRO __CLRD1SX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	ST   X+,R30
	ST   X+,R30
	ST   X+,R30
	ST   X,R30
	.ENDM

	.MACRO __PUTB2SX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	ST   Z,R26
	.ENDM

	.MACRO __PUTW2SX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	ST   Z+,R26
	ST   Z,R27
	.ENDM

	.MACRO __PUTD2SX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	ST   Z+,R26
	ST   Z+,R27
	ST   Z+,R24
	ST   Z,R25
	.ENDM

	.MACRO __PUTBSRX
	MOVW R30,R28
	SUBI R30,LOW(-@1)
	SBCI R31,HIGH(-@1)
	ST   Z,R@0
	.ENDM

	.MACRO __PUTWSRX
	MOVW R30,R28
	SUBI R30,LOW(-@2)
	SBCI R31,HIGH(-@2)
	ST   Z+,R@0
	ST   Z,R@1
	.ENDM

	.MACRO __PUTB1SNX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	LD   R0,X+
	LD   R27,X
	MOV  R26,R0
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X,R30
	.ENDM

	.MACRO __PUTW1SNX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	LD   R0,X+
	LD   R27,X
	MOV  R26,R0
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1SNX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	LD   R0,X+
	LD   R27,X
	MOV  R26,R0
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X+,R30
	ST   X+,R31
	ST   X+,R22
	ST   X,R23
	.ENDM

	.MACRO __MULBRR
	MULS R@0,R@1
	MOVW R30,R0
	.ENDM

	.MACRO __MULBRRU
	MUL  R@0,R@1
	MOVW R30,R0
	.ENDM

	.MACRO __MULBRR0
	MULS R@0,R@1
	.ENDM

	.MACRO __MULBRRU0
	MUL  R@0,R@1
	.ENDM

	.MACRO __MULBNWRU
	LDI  R26,@2
	MUL  R26,R@0
	MOVW R30,R0
	MUL  R26,R@1
	ADD  R31,R0
	.ENDM

;GPIOR0 INITIALIZATION VALUE
	.EQU __GPIOR0_INIT=0x00

	.CSEG
	.ORG 0x00

;START OF CODE MARKER
__START_OF_CODE:

;INTERRUPT VECTORS
	JMP  __RESET
	JMP  0x00
	JMP  0x00
	JMP  0x00
	JMP  0x00
	JMP  0x00
	JMP  0x00
	JMP  0x00
	JMP  0x00
	JMP  0x00
	JMP  0x00
	JMP  0x00
	JMP  0x00
	JMP  0x00
	JMP  0x00
	JMP  0x00
	JMP  0x00
	JMP  0x00
	JMP  0x00
	JMP  0x00
	JMP  0x00
	JMP  0x00
	JMP  0x00
	JMP  0x00
	JMP  0x00
	JMP  0x00

_tbl10_G100:
	.DB  0x10,0x27,0xE8,0x3,0x64,0x0,0xA,0x0
	.DB  0x1,0x0
_tbl16_G100:
	.DB  0x0,0x10,0x0,0x1,0x10,0x0,0x1,0x0

_0x3:
	.DB  0x3,0x3,0x3,0x2,0x2,0xC,0x0,0x8
	.DB  0x0,0x1,0x0,0x6
_0x22:
	.DB  0x1
_0x23:
	.DB  0x1
_0x0:
	.DB  0x43,0x25,0x30,0x32,0x64,0x58,0xA,0x0
	.DB  0x47,0x49,0x52,0x41,0x4E,0x44,0x4F,0x20
	.DB  0x45,0x4E,0x20,0x55,0x2E,0x2E,0x2E,0x20
	.DB  0x0,0x53,0x49,0x53,0x54,0x45,0x4D,0x41
	.DB  0x20,0x4C,0x49,0x53,0x54,0x4F,0x20,0x20
	.DB  0x20,0x0,0x43,0x53,0x54,0x41,0x52,0x54
	.DB  0xA,0x0,0x41,0x56,0x41,0x4E,0x5A,0x41
	.DB  0x4E,0x44,0x4F,0x2E,0x2E,0x2E,0x20,0x20
	.DB  0x20,0x20,0x0,0x43,0x75,0x61,0x64,0x72
	.DB  0x61,0x6E,0x74,0x65,0x3A,0x20,0x25,0x32
	.DB  0x64,0x20,0x20,0x20,0x0,0x4D,0x49,0x44
	.DB  0x49,0x45,0x4E,0x44,0x4F,0x20,0x54,0x49
	.DB  0x45,0x52,0x52,0x41,0x20,0x0,0x53,0x45
	.DB  0x43,0x4F,0x20,0x2D,0x20,0x52,0x45,0x47
	.DB  0x41,0x52,0x21,0x20,0x20,0x20,0x0,0x48
	.DB  0x55,0x4D,0x45,0x44,0x4F,0x20,0x2D,0x20
	.DB  0x4F,0x4B,0x20,0x20,0x20,0x20,0x20,0x0
	.DB  0x43,0x46,0x49,0x4E,0xA,0x0,0x4D,0x41
	.DB  0x50,0x45,0x4F,0x20,0x43,0x4F,0x4D,0x50
	.DB  0x4C,0x45,0x54,0x4F,0x20,0x20,0x0,0x46
	.DB  0x49,0x4E,0x20,0x44,0x45,0x4C,0x20,0x56
	.DB  0x49,0x41,0x4A,0x45,0x20,0x20,0x20,0x0

__GLOBAL_INI_TBL:
	.DW  0x01
	.DW  _cuadrante_actual
	.DW  _0x22*2

	.DW  0x01
	.DW  _fila_actual
	.DW  _0x23*2

	.DW  0x08
	.DW  _0x94
	.DW  _0x0*2+42

	.DW  0x06
	.DW  _0x94+8
	.DW  _0x0*2+136

_0xFFFFFFFF:
	.DW  0

#define __GLOBAL_INI_TBL_PRESENT 1

__RESET:
	CLI

	CLR  R30
	OUT  EECR,R30

;INTERRUPT VECTORS ARE PLACED
;AT THE START OF FLASH
	LDI  R31,1
	OUT  MCUCR,R31
	OUT  MCUCR,R30

;CLEAR R2-R14
	LDI  R24,(14-2)+1
	LDI  R26,2
	CLR  R27
__CLEAR_REG:
	ST   X+,R30
	DEC  R24
	BRNE __CLEAR_REG

;CLEAR SRAM
	LDI  R24,LOW(__CLEAR_SRAM_SIZE)
	LDI  R25,HIGH(__CLEAR_SRAM_SIZE)
	LDI  R26,LOW(__SRAM_START)
	LDI  R27,HIGH(__SRAM_START)
__CLEAR_SRAM:
	ST   X+,R30
	SBIW R24,1
	BRNE __CLEAR_SRAM

;GLOBAL VARIABLES INITIALIZATION
	LDI  R30,LOW(__GLOBAL_INI_TBL*2)
	LDI  R31,HIGH(__GLOBAL_INI_TBL*2)
__GLOBAL_INI_NEXT:
	LPM  R24,Z+
	LPM  R25,Z+
	SBIW R24,0
	BREQ __GLOBAL_INI_END
	LPM  R26,Z+
	LPM  R27,Z+
	LPM  R0,Z+
	LPM  R1,Z+
	MOVW R22,R30
	MOVW R30,R0
__GLOBAL_INI_LOOP:
	LPM  R0,Z+
	ST   X+,R0
	SBIW R24,1
	BRNE __GLOBAL_INI_LOOP
	MOVW R30,R22
	RJMP __GLOBAL_INI_NEXT
__GLOBAL_INI_END:

;GPIOR0 INITIALIZATION
	LDI  R30,__GPIOR0_INIT
	OUT  GPIOR0,R30

;HARDWARE STACK POINTER INITIALIZATION
	LDI  R30,LOW(__SRAM_END-__HEAP_SIZE)
	OUT  SPL,R30
	LDI  R30,HIGH(__SRAM_END-__HEAP_SIZE)
	OUT  SPH,R30

;DATA STACK POINTER INITIALIZATION
	LDI  R28,LOW(__SRAM_START+__DSTACK_SIZE)
	LDI  R29,HIGH(__SRAM_START+__DSTACK_SIZE)

	JMP  _main

	.ESEG
	.ORG 0x00

	.DSEG
	.ORG 0x300

	.CSEG
    .equ __lcd_port=0x0B
    .equ __lcd_RS=2
    .equ __lcd_EN=3
    .equ __lcd_D4=4
    .equ __lcd_D5=5
    .equ __lcd_D6=6
    .equ __lcd_D7=7
; 0000 0018 #endasm
	#ifndef __SLEEP_DEFINED__
	#define __SLEEP_DEFINED__
	.EQU __se_bit=0x01
	.EQU __sm_mask=0x0E
	.EQU __sm_adc_noise_red=0x02
	.EQU __sm_powerdown=0x04
	.EQU __sm_powersave=0x06
	.EQU __sm_standby=0x0C
	.EQU __sm_ext_standby=0x0E
	.SET power_ctrl_reg=smcr
	#endif

	.CSEG
_SetupLCD:
; .FSTART _SetupLCD
	SBIW R28,12
	LDI  R24,12
	__GETWRN 22,23,0
	LDI  R30,LOW(_0x3*2)
	LDI  R31,HIGH(_0x3*2)
	RCALL __INITLOCB
	ST   -Y,R16
;	TableSetup -> Y+1
;	i -> R16
; 0000 001B     SBI __lcd_port-1,__lcd_EN
    SBI __lcd_port-1,__lcd_EN
    SBI __lcd_port-1,__lcd_RS
    SBI __lcd_port-1,__lcd_D4
    SBI __lcd_port-1,__lcd_D5
    SBI __lcd_port-1,__lcd_D6
    SBI __lcd_port-1,__lcd_D7
	LDI  R26,LOW(50)
	LDI  R27,0
	RCALL _delay_ms
	LDI  R16,LOW(0)
_0x5:
	CPI  R16,12
	BRSH _0x6
	LDI  R26,LOW(2)
	LDI  R27,0
	RCALL _delay_ms
	MOV  R30,R16
	LDI  R31,0
	MOVW R26,R28
	ADIW R26,1
	ADD  R26,R30
	ADC  R27,R31
	LD   R26,X
	RCALL _SendDataBitsLCD
	RCALL _PulseEn
	SUBI R16,-1
	RJMP _0x5
_0x6:
	LDI  R30,LOW(12)
	STS  _cursor,R30
	LDS  R26,_cursor
	RCALL _WriteComandLCD
	LDD  R16,Y+0
	ADIW R28,13
	RET
; .FEND
_PulseEn:
; .FSTART _PulseEn
    SBI __lcd_port,__lcd_EN  // EN=1;
    CBI __lcd_port,__lcd_EN // EN=0;
	RET
; .FEND
_SendDataBitsLCD:
; .FSTART _SendDataBitsLCD
	ST   -Y,R16
	MOV  R16,R26
;	dato -> R16
	SBRS R16,3
	RJMP _0x7
	SBI __lcd_port,__lcd_D7
	RJMP _0x8
_0x7:
	CBI __lcd_port,__lcd_D7
_0x8:
	SBRS R16,2
	RJMP _0x9
	SBI __lcd_port,__lcd_D6
	RJMP _0xA
_0x9:
	CBI __lcd_port,__lcd_D6
_0xA:
	SBRS R16,1
	RJMP _0xB
	SBI __lcd_port,__lcd_D5
	RJMP _0xC
_0xB:
	CBI __lcd_port,__lcd_D5
_0xC:
	SBRS R16,0
	RJMP _0xD
	SBI __lcd_port,__lcd_D4
	RJMP _0xE
_0xD:
	CBI __lcd_port,__lcd_D4
_0xE:
	RJMP _0x2060004
; .FEND
_WriteComandLCD:
; .FSTART _WriteComandLCD
	ST   -Y,R17
	ST   -Y,R16
	MOV  R17,R26
;	Comando -> R17
;	tempComando -> R16
	CBI __lcd_port,__lcd_RS
	RCALL SUBOPT_0x0
	RJMP _0x2060007
; .FEND
_CharLCD:
; .FSTART _CharLCD
	ST   -Y,R17
	ST   -Y,R16
	MOV  R17,R26
;	dato -> R17
;	tempdato -> R16
	SBI __lcd_port,__lcd_RS
	RCALL SUBOPT_0x0
	RJMP _0x2060007
; .FEND
_StringLCD:
; .FSTART _StringLCD
	RCALL SUBOPT_0x1
;	Mensaje -> R17,R18
;	i -> R16
_0x10:
	RCALL SUBOPT_0x2
	LPM  R26,Z
	RCALL _CharLCD
	MOV  R30,R16
	LDI  R31,0
	ADD  R30,R17
	ADC  R31,R18
	LPM  R30,Z
	CPI  R30,0
	BRNE _0x10
	RCALL __LOADLOCR3
	RJMP _0x2060006
; .FEND
;	Mensaje -> R19,R20
;	tiempo -> R17,R18
;	i -> R16
_StringLCDVar:
; .FSTART _StringLCDVar
	RCALL SUBOPT_0x1
;	Mensaje -> R17,R18
;	i -> R16
_0x16:
	RCALL SUBOPT_0x2
	LD   R26,Z
	RCALL _CharLCD
	__GETW2R 17,18
	CLR  R30
	ADD  R26,R16
	ADC  R27,R30
	LD   R30,X
	CPI  R30,0
	BRNE _0x16
	RCALL __LOADLOCR3
	RJMP _0x2060006
; .FEND
_MoveCursor:
; .FSTART _MoveCursor
	RCALL SUBOPT_0x3
;	x -> R17
;	y -> R16
	MOV  R30,R16
	LDI  R31,0
	SBIW R30,0
	BRNE _0x1B
	MOV  R26,R17
	SUBI R26,-LOW(128)
	RJMP _0xA2
_0x1B:
	CPI  R30,LOW(0x1)
	LDI  R26,HIGH(0x1)
	CPC  R31,R26
	BRNE _0x1C
	MOV  R26,R17
	SUBI R26,-LOW(192)
	RJMP _0xA2
_0x1C:
	CPI  R30,LOW(0x2)
	LDI  R26,HIGH(0x2)
	CPC  R31,R26
	BRNE _0x1D
	MOV  R26,R17
	SUBI R26,-LOW(148)
	RJMP _0xA2
_0x1D:
	CPI  R30,LOW(0x3)
	LDI  R26,HIGH(0x3)
	CPC  R31,R26
	BRNE _0x1A
	MOV  R26,R17
	SUBI R26,-LOW(212)
_0xA2:
	RCALL _WriteComandLCD
_0x1A:
	RJMP _0x2060005
; .FEND
;	NoCaracter -> R19
;	datos -> R17,R18
;	i -> R16

	.DSEG
;void uart_init(void)
; 0000 003A {

	.CSEG
_uart_init:
; .FSTART _uart_init
; 0000 003B // Configura el baud rate (registro de 16 bits)
; 0000 003C UBRR0H = (unsigned char)(UART_UBRR_VAL >> 8);
	LDI  R30,LOW(0)
	STS  197,R30
; 0000 003D UBRR0L = (unsigned char)(UART_UBRR_VAL);
	LDI  R30,LOW(5)
	STS  196,R30
; 0000 003E 
; 0000 003F // Habilita el transmisor (TX). No se necesita receptor por ahora.
; 0000 0040 UCSR0B = (1<<TXEN0);
	LDI  R30,LOW(8)
	STS  193,R30
; 0000 0041 
; 0000 0042 // Formato de frame: 8 bits de datos, 1 bit de stop, sin paridad
; 0000 0043 UCSR0C = (1<<UCSZ01) | (1<<UCSZ00);
	LDI  R30,LOW(6)
	STS  194,R30
; 0000 0044 }
	RET
; .FEND
;void uart_send_byte(unsigned char data)
; 0000 0048 {
_uart_send_byte:
; .FSTART _uart_send_byte
; 0000 0049 // Espera a que el buffer de transmisi�n est� vac�o
; 0000 004A while (!(UCSR0A & (1<<UDRE0)));
	ST   -Y,R16
	MOV  R16,R26
;	data -> R16
_0x24:
	LDS  R30,192
	ANDI R30,LOW(0x20)
	BREQ _0x24
; 0000 004B UDR0 = data;
	STS  198,R16
; 0000 004C }
	RJMP _0x2060004
; .FEND
;void uart_send_string(char *str)
; 0000 0050 {
_uart_send_string:
; .FSTART _uart_send_string
; 0000 0051 while (*str)
	ST   -Y,R17
	ST   -Y,R16
	MOVW R16,R26
;	*str -> R16,R17
_0x27:
	MOVW R26,R16
	LD   R30,X
	CPI  R30,0
	BREQ _0x29
; 0000 0052 {
; 0000 0053 uart_send_byte(*str);
	LD   R26,X
	RCALL _uart_send_byte
; 0000 0054 str++;
	__ADDWRN 16,17,1
; 0000 0055 }
	RJMP _0x27
_0x29:
; 0000 0056 }
_0x2060007:
	LD   R16,Y+
	LD   R17,Y+
	RET
; .FEND
;void uart_enviar_estado(unsigned char cuadrante, unsigned char humedo)
; 0000 005B {
_uart_enviar_estado:
; .FSTART _uart_enviar_estado
; 0000 005C // Construye el mensaje con sprintf y lo env�a
; 0000 005D sprintf(buffer_uart, "C%02dX\n", cuadrante);
	RCALL SUBOPT_0x3
;	cuadrante -> R17
;	humedo -> R16
	LDI  R30,LOW(_buffer_uart)
	LDI  R31,HIGH(_buffer_uart)
	ST   -Y,R31
	ST   -Y,R30
	__POINTW1FN _0x0,0
	ST   -Y,R31
	ST   -Y,R30
	MOV  R30,R17
	RCALL SUBOPT_0x4
; 0000 005E // Reemplaza la 'X' con el estado real
; 0000 005F buffer_uart[3] = humedo ? 'H' : 'S';
	CPI  R16,0
	BREQ _0x2A
	LDI  R30,LOW(72)
	RJMP _0x2B
_0x2A:
	LDI  R30,LOW(83)
_0x2B:
	__PUTB1MN _buffer_uart,3
; 0000 0060 uart_send_string(buffer_uart);
	LDI  R26,LOW(_buffer_uart)
	LDI  R27,HIGH(_buffer_uart)
	RCALL _uart_send_string
; 0000 0061 }
_0x2060005:
	LDD  R17,Y+1
	LDD  R16,Y+0
_0x2060006:
	ADIW R28,3
	RET
; .FEND
;unsigned int read_adc(unsigned char adc_input)
; 0000 006A {
_read_adc:
; .FSTART _read_adc
; 0000 006B ADMUX = adc_input | ADC_VREF_TYPE;  // Qu� pin leer y qu� voltaje usar
	ST   -Y,R16
	MOV  R16,R26
;	adc_input -> R16
	MOV  R30,R16
	ORI  R30,0x40
	STS  124,R30
; 0000 006C delay_us(10);                        // Pausa para estabilizar
	__DELAY_USB 3
; 0000 006D ADCSRA |= (1<<ADSC);                 // Empieza a procesar
	LDS  R30,122
	ORI  R30,0x40
	STS  122,R30
; 0000 006E while ((ADCSRA & (1<<ADIF))==0);     // Espera hasta que est� procesado
_0x2D:
	LDS  R30,122
	ANDI R30,LOW(0x10)
	BREQ _0x2D
; 0000 006F ADCSRA |= (1<<ADIF);                 // Listo para la siguiente lectura
	LDS  R30,122
	ORI  R30,0x10
	STS  122,R30
; 0000 0070 return ADCW;                         // Devuelve resoluci�n completa de 10 bits
	LDS  R30,120
	LDS  R31,120+1
	RJMP _0x2060004
; 0000 0071 }
; .FEND
;void servo_arriba(void)
; 0000 007A {
_servo_arriba:
; .FSTART _servo_arriba
; 0000 007B unsigned char i;
; 0000 007C for(i=0; i<40; i++)
	ST   -Y,R16
;	i -> R16
	LDI  R16,LOW(0)
_0x31:
	CPI  R16,40
	BRSH _0x32
; 0000 007D {
; 0000 007E // Pulso de 1ms = 0 grados
; 0000 007F PORTB.4 = 1;
	SBI  0x5,4
; 0000 0080 delay_us(1000);  // Pulso de 1ms
	__DELAY_USW 250
; 0000 0081 PORTB.4 = 0;
	CBI  0x5,4
; 0000 0082 delay_us(19000); // Completa el periodo de 20ms
	__DELAY_USW 4750
; 0000 0083 }
	SUBI R16,-1
	RJMP _0x31
_0x32:
; 0000 0084 }
	RJMP _0x2060004
; .FEND
;void servo_abajo(void)
; 0000 0087 {
_servo_abajo:
; .FSTART _servo_abajo
; 0000 0088 unsigned char i;
; 0000 0089 for(i=0; i<40; i++)
	ST   -Y,R16
;	i -> R16
	LDI  R16,LOW(0)
_0x38:
	CPI  R16,40
	BRSH _0x39
; 0000 008A {
; 0000 008B // Pulso de 2ms = 180 grados
; 0000 008C PORTB.4 = 1;
	SBI  0x5,4
; 0000 008D delay_us(2000);  // Pulso de 2ms
	__DELAY_USW 500
; 0000 008E PORTB.4 = 0;
	CBI  0x5,4
; 0000 008F delay_us(18000); // Completa el periodo de 20ms
	__DELAY_USW 4500
; 0000 0090 }
	SUBI R16,-1
	RJMP _0x38
_0x39:
; 0000 0091 }
_0x2060004:
	LD   R16,Y+
	RET
; .FEND
;void frenar(void)
; 0000 0099 {
_frenar:
; .FSTART _frenar
; 0000 009A // Apaga Puente H Delantero (PORTC)
; 0000 009B PORTC.1 = 0; PORTC.2 = 0;
	CBI  0x8,1
	CBI  0x8,2
; 0000 009C PORTC.3 = 0; PORTC.4 = 0;
	CBI  0x8,3
	CBI  0x8,4
; 0000 009D 
; 0000 009E // Apaga Puente H Trasero (PORTB y PC5)
; 0000 009F PORTB.0 = 0; PORTB.1 = 0;
	CBI  0x5,0
	CBI  0x5,1
; 0000 00A0 PORTB.2 = 0; PORTC.5 = 0;
	CBI  0x5,2
	RJMP _0x2060003
; 0000 00A1 }
; .FEND
;void avanzar(void)
; 0000 00A4 {
_avanzar:
; .FSTART _avanzar
; 0000 00A5 frenar();
	RCALL SUBOPT_0x5
; 0000 00A6 // Lado Izquierdo Adelante (Delantero y Trasero)
; 0000 00A7 PORTC.1 = 1; PORTC.2 = 0;
; 0000 00A8 PORTB.0 = 1; PORTB.1 = 0;
; 0000 00A9 
; 0000 00AA // Lado Derecho Adelante (Delantero y Trasero)
; 0000 00AB PORTC.3 = 1; PORTC.4 = 0;
	RJMP _0x2060002
; 0000 00AC PORTB.2 = 1; PORTC.5 = 0;
; 0000 00AD }
; .FEND
;void girar_derecha(void)
; 0000 00B0 {
_girar_derecha:
; .FSTART _girar_derecha
; 0000 00B1 frenar();
	RCALL SUBOPT_0x5
; 0000 00B2 // Lado Izquierdo Adelante
; 0000 00B3 PORTC.1 = 1; PORTC.2 = 0;
; 0000 00B4 PORTB.0 = 1; PORTB.1 = 0;
; 0000 00B5 
; 0000 00B6 // Lado Derecho Atr�s (Giro tipo tanque)
; 0000 00B7 PORTC.3 = 0; PORTC.4 = 1;
	CBI  0x8,3
	SBI  0x8,4
; 0000 00B8 PORTB.2 = 0; PORTC.5 = 1;
	CBI  0x5,2
	SBI  0x8,5
; 0000 00B9 }
	RET
; .FEND
;void girar_izquierda(void)
; 0000 00BC {
_girar_izquierda:
; .FSTART _girar_izquierda
; 0000 00BD frenar();
	RCALL _frenar
; 0000 00BE // Lado Izquierdo Atr�s
; 0000 00BF PORTC.1 = 0; PORTC.2 = 1;
	CBI  0x8,1
	SBI  0x8,2
; 0000 00C0 PORTB.0 = 0; PORTB.1 = 1;
	CBI  0x5,0
	SBI  0x5,1
; 0000 00C1 
; 0000 00C2 // Lado Derecho Adelante
; 0000 00C3 PORTC.3 = 1; PORTC.4 = 0;
_0x2060002:
	SBI  0x8,3
	CBI  0x8,4
; 0000 00C4 PORTB.2 = 1; PORTC.5 = 0;
	SBI  0x5,2
_0x2060003:
	CBI  0x8,5
; 0000 00C5 }
	RET
; .FEND
;void realizar_giro_en_u(void)
; 0000 00CD {
_realizar_giro_en_u:
; .FSTART _realizar_giro_en_u
; 0000 00CE MoveCursor(0,0);
	RCALL SUBOPT_0x6
; 0000 00CF StringLCD("GIRANDO EN U... ");
	__POINTW2FN _0x0,8
	RCALL _StringLCD
; 0000 00D0 
; 0000 00D1 if (fila_actual % 2 != 0)
	LDS  R26,_fila_actual
	CLR  R27
	LDI  R30,LOW(2)
	LDI  R31,HIGH(2)
	RCALL __MODW21
	SBIW R30,0
	BREQ _0x7E
; 0000 00D2 {
; 0000 00D3 // Filas impares: gira a la derecha
; 0000 00D4 girar_derecha();   delay_ms(TIEMPO_GIRO_90);
	RCALL _girar_derecha
	RCALL SUBOPT_0x7
; 0000 00D5 avanzar();         delay_ms(TIEMPO_10CM);
; 0000 00D6 girar_derecha();   delay_ms(TIEMPO_GIRO_90);
	RCALL _girar_derecha
	RJMP _0xA3
; 0000 00D7 }
; 0000 00D8 else
_0x7E:
; 0000 00D9 {
; 0000 00DA // Filas pares: gira a la izquierda
; 0000 00DB girar_izquierda(); delay_ms(TIEMPO_GIRO_90);
	RCALL _girar_izquierda
	RCALL SUBOPT_0x7
; 0000 00DC avanzar();         delay_ms(TIEMPO_10CM);
; 0000 00DD girar_izquierda(); delay_ms(TIEMPO_GIRO_90);
	RCALL _girar_izquierda
_0xA3:
	LDI  R26,LOW(800)
	LDI  R27,HIGH(800)
	RCALL _delay_ms
; 0000 00DE }
; 0000 00DF frenar();
	RCALL _frenar
; 0000 00E0 delay_ms(500);
	LDI  R26,LOW(500)
	LDI  R27,HIGH(500)
	RCALL _delay_ms
; 0000 00E1 }
	RET
; .FEND
;void main(void)
; 0000 00E9 {
_main:
; .FSTART _main
; 0000 00EA // --- INICIALIZACI�N DE ADC PARA RELOJ DE 1 MHz ---
; 0000 00EB // Prescaler en 8 (1 MHz / 8 = 125 kHz de frecuencia de muestreo)
; 0000 00EC ADCSRA = (1<<ADEN)  | (0<<ADSC)  | (0<<ADATE) | (0<<ADIF) |
; 0000 00ED (0<<ADIE)  | (0<<ADPS2) | (1<<ADPS1) | (1<<ADPS0);
	LDI  R30,LOW(131)
	STS  122,R30
; 0000 00EE ADCSRB = (0<<ADTS2) | (0<<ADTS1) | (0<<ADTS0);
	LDI  R30,LOW(0)
	STS  123,R30
; 0000 00EF DIDR0  = (1<<ADC0D); // Desactiva entrada digital en A0 para reducir ruido anal�gico
	LDI  R30,LOW(1)
	STS  126,R30
; 0000 00F0 
; 0000 00F1 // --- INICIALIZACI�N DE UART ---
; 0000 00F2 uart_init();
	RCALL _uart_init
; 0000 00F3 
; 0000 00F4 // --- CONFIGURACI�N DE SALIDAS DIGITALES ---
; 0000 00F5 SetupLCD();
	RCALL _SetupLCD
; 0000 00F6 
; 0000 00F7 // Pines Puente H Delantero (Salidas)
; 0000 00F8 DDRC.1 = 1; DDRC.2 = 1;
	SBI  0x7,1
	SBI  0x7,2
; 0000 00F9 DDRC.3 = 1; DDRC.4 = 1;
	SBI  0x7,3
	SBI  0x7,4
; 0000 00FA 
; 0000 00FB // Pines Puente H Trasero (Salidas)
; 0000 00FC DDRB.0 = 1; DDRB.1 = 1;
	SBI  0x4,0
	SBI  0x4,1
; 0000 00FD DDRB.2 = 1; DDRC.5 = 1;
	SBI  0x4,2
	SBI  0x7,5
; 0000 00FE 
; 0000 00FF // Pin del Servo (Salida)
; 0000 0100 DDRB.4 = 1;
	SBI  0x4,4
; 0000 0101 
; 0000 0102 // Pin TX de UART ya es salida por hardware al habilitar TXEN0
; 0000 0103 // pero se configura expl�citamente por claridad
; 0000 0104 DDRD.1 = 1;
	SBI  0xA,1
; 0000 0105 
; 0000 0106 frenar();
	RCALL _frenar
; 0000 0107 servo_arriba(); // Iniciar con el brazo del sensor arriba
	RCALL _servo_arriba
; 0000 0108 
; 0000 0109 MoveCursor(0,0);
	RCALL SUBOPT_0x6
; 0000 010A StringLCD("SISTEMA LISTO   ");
	__POINTW2FN _0x0,25
	RCALL _StringLCD
; 0000 010B delay_ms(3000); // 3 segundos para colocar el carro en el suelo
	LDI  R26,LOW(3000)
	LDI  R27,HIGH(3000)
	RCALL _delay_ms
; 0000 010C 
; 0000 010D // Notifica a la Raspberry Pi que el ciclo va a comenzar
; 0000 010E uart_send_string("CSTART\n");
	__POINTW2MN _0x94,0
	RCALL _uart_send_string
; 0000 010F 
; 0000 0110 while (1)
_0x95:
; 0000 0111 {
; 0000 0112 if (cuadrante_actual <= 36)
	LDS  R26,_cuadrante_actual
	CPI  R26,LOW(0x25)
	BRLO PC+2
	RJMP _0x98
; 0000 0113 {
; 0000 0114 // 1. Desplegar cuadrante actual e iniciar avance
; 0000 0115 MoveCursor(0,0);
	RCALL SUBOPT_0x6
; 0000 0116 StringLCD("AVANZANDO...    ");
	__POINTW2FN _0x0,50
	RCALL SUBOPT_0x8
; 0000 0117 MoveCursor(0,1);
; 0000 0118 sprintf(buffer_lcd, "Cuadrante: %2d   ", cuadrante_actual);
	LDI  R30,LOW(_buffer_lcd)
	LDI  R31,HIGH(_buffer_lcd)
	ST   -Y,R31
	ST   -Y,R30
	__POINTW1FN _0x0,67
	ST   -Y,R31
	ST   -Y,R30
	LDS  R30,_cuadrante_actual
	RCALL SUBOPT_0x4
; 0000 0119 StringLCDVar(buffer_lcd);
	LDI  R26,LOW(_buffer_lcd)
	LDI  R27,HIGH(_buffer_lcd)
	RCALL _StringLCDVar
; 0000 011A 
; 0000 011B avanzar();
	RCALL _avanzar
; 0000 011C delay_ms(TIEMPO_10CM);
	LDI  R26,LOW(1200)
	LDI  R27,HIGH(1200)
	RCALL _delay_ms
; 0000 011D frenar();
	RCALL _frenar
; 0000 011E 
; 0000 011F // 2. Proceso mec�nico de medici�n
; 0000 0120 MoveCursor(0,0);
	RCALL SUBOPT_0x6
; 0000 0121 StringLCD("MIDIENDO TIERRA ");
	__POINTW2FN _0x0,85
	RCALL _StringLCD
; 0000 0122 
; 0000 0123 servo_abajo();          // Introduce el sensor en la tierra
	RCALL _servo_abajo
; 0000 0124 delay_ms(500);          // Pausa para estabilizaci�n f�sica
	LDI  R26,LOW(500)
	LDI  R27,HIGH(500)
	RCALL _delay_ms
; 0000 0125 
; 0000 0126 valor_humedad = read_adc(0); // Lectura del pin A0
	LDI  R26,LOW(0)
	RCALL _read_adc
	STS  _valor_humedad,R30
	STS  _valor_humedad+1,R31
; 0000 0127 
; 0000 0128 // 3. Analizar datos del suelo y enviar resultado
; 0000 0129 MoveCursor(0,1);
	LDI  R30,LOW(0)
	ST   -Y,R30
	LDI  R26,LOW(1)
	RCALL _MoveCursor
; 0000 012A if (valor_humedad > UMBRAL_SECO)
	LDS  R26,_valor_humedad
	LDS  R27,_valor_humedad+1
	CPI  R26,LOW(0x259)
	LDI  R30,HIGH(0x259)
	CPC  R27,R30
	BRLO _0x99
; 0000 012B {
; 0000 012C // Tierra seca: avisa en pantalla y notifica a la Raspberry Pi
; 0000 012D StringLCD("SECO - REGAR!   ");
	__POINTW2FN _0x0,102
	RCALL SUBOPT_0x9
; 0000 012E uart_enviar_estado(cuadrante_actual, 0); // 0 = Seco
	LDI  R26,LOW(0)
	RJMP _0xA4
; 0000 012F }
; 0000 0130 else
_0x99:
; 0000 0131 {
; 0000 0132 // Tierra h�meda: confirma en pantalla y notifica a la Raspberry Pi
; 0000 0133 StringLCD("HUMEDO - OK     ");
	__POINTW2FN _0x0,119
	RCALL SUBOPT_0x9
; 0000 0134 uart_enviar_estado(cuadrante_actual, 1); // 1 = H�medo
	LDI  R26,LOW(1)
_0xA4:
	RCALL _uart_enviar_estado
; 0000 0135 }
; 0000 0136 
; 0000 0137 delay_ms(2000); // Mantener el mensaje en pantalla por 2 segundos
	LDI  R26,LOW(2000)
	LDI  R27,HIGH(2000)
	RCALL _delay_ms
; 0000 0138 
; 0000 0139 servo_arriba(); // Retraer sensor antes de reiniciar marcha
	RCALL _servo_arriba
; 0000 013A 
; 0000 013B // 4. Verificaci�n de final de fila (M�ltiplos de 6)
; 0000 013C if (cuadrante_actual % 6 == 0)
	LDS  R26,_cuadrante_actual
	CLR  R27
	LDI  R30,LOW(6)
	LDI  R31,HIGH(6)
	RCALL __MODW21
	SBIW R30,0
	BRNE _0x9B
; 0000 013D {
; 0000 013E if (cuadrante_actual < 36)
	LDS  R26,_cuadrante_actual
	CPI  R26,LOW(0x24)
	BRSH _0x9C
; 0000 013F {
; 0000 0140 realizar_giro_en_u();
	RCALL _realizar_giro_en_u
; 0000 0141 fila_actual++;
	LDS  R30,_fila_actual
	SUBI R30,-LOW(1)
	STS  _fila_actual,R30
; 0000 0142 }
; 0000 0143 }
_0x9C:
; 0000 0144 
; 0000 0145 cuadrante_actual++;
_0x9B:
	LDS  R30,_cuadrante_actual
	SUBI R30,-LOW(1)
	STS  _cuadrante_actual,R30
; 0000 0146 }
; 0000 0147 else
	RJMP _0x9D
_0x98:
; 0000 0148 {
; 0000 0149 // --- FIN DE LA MATRIZ DE RECORRIDO ---
; 0000 014A frenar();
	RCALL _frenar
; 0000 014B 
; 0000 014C // Notifica a la Raspberry Pi que el mapeo termin�
; 0000 014D uart_send_string("CFIN\n");
	__POINTW2MN _0x94,8
	RCALL _uart_send_string
; 0000 014E 
; 0000 014F MoveCursor(0,0);
	RCALL SUBOPT_0x6
; 0000 0150 StringLCD("MAPEO COMPLETO  ");
	__POINTW2FN _0x0,142
	RCALL SUBOPT_0x8
; 0000 0151 MoveCursor(0,1);
; 0000 0152 StringLCD("FIN DEL VIAJE   ");
	__POINTW2FN _0x0,159
	RCALL _StringLCD
; 0000 0153 while(1); // Bloqueo de seguridad final
_0x9E:
	RJMP _0x9E
; 0000 0154 }
_0x9D:
; 0000 0155 }
	RJMP _0x95
; 0000 0156 }
_0xA1:
	RJMP _0xA1
; .FEND

	.DSEG
_0x94:
	.BYTE 0xE
	#ifndef __SLEEP_DEFINED__
	#define __SLEEP_DEFINED__
	.EQU __se_bit=0x01
	.EQU __sm_mask=0x0E
	.EQU __sm_adc_noise_red=0x02
	.EQU __sm_powerdown=0x04
	.EQU __sm_powersave=0x06
	.EQU __sm_standby=0x0C
	.EQU __sm_ext_standby=0x0E
	.SET power_ctrl_reg=smcr
	#endif

	.CSEG
_put_buff_G100:
; .FSTART _put_buff_G100
	RCALL __SAVELOCR5
	MOVW R18,R26
	LDD  R20,Y+5
	ADIW R26,2
	__GETW1P
	SBIW R30,0
	BREQ _0x2000016
	MOVW R26,R18
	RCALL SUBOPT_0xA
	MOVW R16,R30
	SBIW R30,0
	BREQ _0x2000018
	__CPWRN 16,17,2
	BRLO _0x2000019
	MOVW R30,R16
	SBIW R30,1
	MOVW R16,R30
	__PUTW1RNS 18,4
_0x2000018:
	MOVW R26,R18
	ADIW R26,2
	RCALL SUBOPT_0xB
	SBIW R30,1
	ST   Z,R20
_0x2000019:
	MOVW R26,R18
	__GETW1P
	TST  R31
	BRMI _0x200001A
	RCALL SUBOPT_0xB
_0x200001A:
	RJMP _0x200001B
_0x2000016:
	MOVW R26,R18
	LDI  R30,LOW(65535)
	LDI  R31,HIGH(65535)
	ST   X+,R30
	ST   X,R31
_0x200001B:
	RCALL __LOADLOCR5
	ADIW R28,6
	RET
; .FEND
__print_G100:
; .FSTART __print_G100
	ST   -Y,R27
	ST   -Y,R26
	SBIW R28,6
	RCALL __SAVELOCR6
	LDI  R16,0
	LDD  R26,Y+12
	LDD  R27,Y+12+1
	LDI  R30,LOW(0)
	LDI  R31,HIGH(0)
	ST   X+,R30
	ST   X,R31
_0x200001C:
	LDD  R30,Y+18
	LDD  R31,Y+18+1
	ADIW R30,1
	STD  Y+18,R30
	STD  Y+18+1,R31
	SBIW R30,1
	LPM  R30,Z
	MOV  R19,R30
	CPI  R30,0
	BRNE PC+2
	RJMP _0x200001E
	MOV  R30,R16
	CPI  R30,0
	BRNE _0x2000022
	CPI  R19,37
	BRNE _0x2000023
	LDI  R16,LOW(1)
	RJMP _0x2000024
_0x2000023:
	RCALL SUBOPT_0xC
_0x2000024:
	RJMP _0x2000021
_0x2000022:
	CPI  R30,LOW(0x1)
	BRNE _0x2000025
	CPI  R19,37
	BRNE _0x2000026
	RCALL SUBOPT_0xC
	RJMP _0x20000D2
_0x2000026:
	LDI  R16,LOW(2)
	LDI  R21,LOW(0)
	LDI  R17,LOW(0)
	CPI  R19,45
	BRNE _0x2000027
	LDI  R17,LOW(1)
	RJMP _0x2000021
_0x2000027:
	CPI  R19,43
	BRNE _0x2000028
	LDI  R21,LOW(43)
	RJMP _0x2000021
_0x2000028:
	CPI  R19,32
	BRNE _0x2000029
	LDI  R21,LOW(32)
	RJMP _0x2000021
_0x2000029:
	RJMP _0x200002A
_0x2000025:
	CPI  R30,LOW(0x2)
	BRNE _0x200002B
_0x200002A:
	LDI  R20,LOW(0)
	LDI  R16,LOW(3)
	CPI  R19,48
	BRNE _0x200002C
	ORI  R17,LOW(128)
	RJMP _0x2000021
_0x200002C:
	RJMP _0x200002D
_0x200002B:
	CPI  R30,LOW(0x3)
	BREQ PC+2
	RJMP _0x2000021
_0x200002D:
	CPI  R19,48
	BRLO _0x2000030
	CPI  R19,58
	BRLO _0x2000031
_0x2000030:
	RJMP _0x200002F
_0x2000031:
	LDI  R26,LOW(10)
	MUL  R20,R26
	MOV  R20,R0
	MOV  R30,R19
	SUBI R30,LOW(48)
	ADD  R20,R30
	RJMP _0x2000021
_0x200002F:
	MOV  R30,R19
	CPI  R30,LOW(0x63)
	BRNE _0x2000035
	RCALL SUBOPT_0xD
	LDD  R30,Y+16
	LDD  R31,Y+16+1
	LDD  R26,Z+4
	ST   -Y,R26
	RCALL SUBOPT_0xE
	RJMP _0x2000036
_0x2000035:
	CPI  R30,LOW(0x73)
	BRNE _0x2000038
	RCALL SUBOPT_0xD
	RCALL SUBOPT_0xF
	RCALL _strlen
	MOV  R16,R30
	RJMP _0x2000039
_0x2000038:
	CPI  R30,LOW(0x70)
	BRNE _0x200003B
	RCALL SUBOPT_0xD
	RCALL SUBOPT_0xF
	RCALL _strlenf
	MOV  R16,R30
	ORI  R17,LOW(8)
_0x2000039:
	ORI  R17,LOW(2)
	ANDI R17,LOW(127)
	LDI  R18,LOW(0)
	RJMP _0x200003C
_0x200003B:
	CPI  R30,LOW(0x64)
	BREQ _0x200003F
	CPI  R30,LOW(0x69)
	BRNE _0x2000040
_0x200003F:
	ORI  R17,LOW(4)
	RJMP _0x2000041
_0x2000040:
	CPI  R30,LOW(0x75)
	BRNE _0x2000042
_0x2000041:
	LDI  R30,LOW(_tbl10_G100*2)
	LDI  R31,HIGH(_tbl10_G100*2)
	STD  Y+6,R30
	STD  Y+6+1,R31
	LDI  R16,LOW(5)
	RJMP _0x2000043
_0x2000042:
	CPI  R30,LOW(0x58)
	BRNE _0x2000045
	ORI  R17,LOW(8)
	RJMP _0x2000046
_0x2000045:
	CPI  R30,LOW(0x78)
	BREQ PC+2
	RJMP _0x2000077
_0x2000046:
	LDI  R30,LOW(_tbl16_G100*2)
	LDI  R31,HIGH(_tbl16_G100*2)
	STD  Y+6,R30
	STD  Y+6+1,R31
	LDI  R16,LOW(4)
_0x2000043:
	SBRS R17,2
	RJMP _0x2000048
	RCALL SUBOPT_0xD
	LDD  R26,Y+16
	LDD  R27,Y+16+1
	ADIW R26,4
	LD   R30,X+
	LD   R31,X+
	STD  Y+10,R30
	STD  Y+10+1,R31
	LDD  R26,Y+11
	TST  R26
	BRPL _0x2000049
	RCALL __ANEGW1
	STD  Y+10,R30
	STD  Y+10+1,R31
	LDI  R21,LOW(45)
_0x2000049:
	CPI  R21,0
	BREQ _0x200004A
	SUBI R16,-LOW(1)
	RJMP _0x200004B
_0x200004A:
	ANDI R17,LOW(251)
_0x200004B:
	RJMP _0x200004C
_0x2000048:
	RCALL SUBOPT_0xD
	LDD  R26,Y+16
	LDD  R27,Y+16+1
	RCALL SUBOPT_0xA
	STD  Y+10,R30
	STD  Y+10+1,R31
_0x200004C:
_0x200003C:
	SBRC R17,0
	RJMP _0x200004D
_0x200004E:
	CP   R16,R20
	BRSH _0x2000050
	SBRS R17,7
	RJMP _0x2000051
	SBRS R17,2
	RJMP _0x2000052
	ANDI R17,LOW(251)
	MOV  R19,R21
	SUBI R16,LOW(1)
	RJMP _0x2000053
_0x2000052:
	LDI  R19,LOW(48)
_0x2000053:
	RJMP _0x2000054
_0x2000051:
	LDI  R19,LOW(32)
_0x2000054:
	RCALL SUBOPT_0xC
	SUBI R20,LOW(1)
	RJMP _0x200004E
_0x2000050:
_0x200004D:
	MOV  R18,R16
	SBRS R17,1
	RJMP _0x2000055
_0x2000056:
	CPI  R18,0
	BREQ _0x2000058
	SBRS R17,3
	RJMP _0x2000059
	LDD  R30,Y+6
	LDD  R31,Y+6+1
	LPM  R19,Z+
	STD  Y+6,R30
	STD  Y+6+1,R31
	RJMP _0x200005A
_0x2000059:
	LDD  R26,Y+6
	LDD  R27,Y+6+1
	LD   R19,X+
	STD  Y+6,R26
	STD  Y+6+1,R27
_0x200005A:
	RCALL SUBOPT_0xC
	CPI  R20,0
	BREQ _0x200005B
	SUBI R20,LOW(1)
_0x200005B:
	SUBI R18,LOW(1)
	RJMP _0x2000056
_0x2000058:
	RJMP _0x200005C
_0x2000055:
_0x200005E:
	LDI  R19,LOW(48)
	LDD  R30,Y+6
	LDD  R31,Y+6+1
	RCALL __GETW1PF
	STD  Y+8,R30
	STD  Y+8+1,R31
	LDD  R30,Y+6
	LDD  R31,Y+6+1
	ADIW R30,2
	STD  Y+6,R30
	STD  Y+6+1,R31
_0x2000060:
	LDD  R30,Y+8
	LDD  R31,Y+8+1
	LDD  R26,Y+10
	LDD  R27,Y+10+1
	CP   R26,R30
	CPC  R27,R31
	BRLO _0x2000062
	SUBI R19,-LOW(1)
	LDD  R26,Y+8
	LDD  R27,Y+8+1
	LDD  R30,Y+10
	LDD  R31,Y+10+1
	SUB  R30,R26
	SBC  R31,R27
	STD  Y+10,R30
	STD  Y+10+1,R31
	RJMP _0x2000060
_0x2000062:
	CPI  R19,58
	BRLO _0x2000063
	SBRS R17,3
	RJMP _0x2000064
	SUBI R19,-LOW(7)
	RJMP _0x2000065
_0x2000064:
	SUBI R19,-LOW(39)
_0x2000065:
_0x2000063:
	SBRC R17,4
	RJMP _0x2000067
	CPI  R19,49
	BRSH _0x2000069
	LDD  R26,Y+8
	LDD  R27,Y+8+1
	SBIW R26,1
	BRNE _0x2000068
_0x2000069:
	RJMP _0x20000D3
_0x2000068:
	CP   R20,R18
	BRLO _0x200006D
	SBRS R17,0
	RJMP _0x200006E
_0x200006D:
	RJMP _0x200006C
_0x200006E:
	LDI  R19,LOW(32)
	SBRS R17,7
	RJMP _0x200006F
	LDI  R19,LOW(48)
_0x20000D3:
	ORI  R17,LOW(16)
	SBRS R17,2
	RJMP _0x2000070
	ANDI R17,LOW(251)
	ST   -Y,R21
	RCALL SUBOPT_0xE
	CPI  R20,0
	BREQ _0x2000071
	SUBI R20,LOW(1)
_0x2000071:
_0x2000070:
_0x200006F:
_0x2000067:
	RCALL SUBOPT_0xC
	CPI  R20,0
	BREQ _0x2000072
	SUBI R20,LOW(1)
_0x2000072:
_0x200006C:
	SUBI R18,LOW(1)
	LDD  R26,Y+8
	LDD  R27,Y+8+1
	SBIW R26,2
	BRLO _0x200005F
	RJMP _0x200005E
_0x200005F:
_0x200005C:
	SBRS R17,0
	RJMP _0x2000073
_0x2000074:
	CPI  R20,0
	BREQ _0x2000076
	SUBI R20,LOW(1)
	LDI  R30,LOW(32)
	ST   -Y,R30
	RCALL SUBOPT_0xE
	RJMP _0x2000074
_0x2000076:
_0x2000073:
_0x2000077:
_0x2000036:
_0x20000D2:
	LDI  R16,LOW(0)
_0x2000021:
	RJMP _0x200001C
_0x200001E:
	LDD  R26,Y+12
	LDD  R27,Y+12+1
	LD   R30,X+
	LD   R31,X+
	RCALL __LOADLOCR6
	ADIW R28,20
	RET
; .FEND
_sprintf:
; .FSTART _sprintf
	PUSH R15
	MOV  R15,R24
	SBIW R28,6
	RCALL __SAVELOCR6
	MOVW R30,R28
	__ADDW1R15
	__GETWRZ 20,21,14
	MOV  R0,R20
	OR   R0,R21
	BRNE _0x2000078
	LDI  R30,LOW(65535)
	LDI  R31,HIGH(65535)
	RJMP _0x2060001
_0x2000078:
	MOVW R26,R28
	ADIW R26,8
	__ADDW2R15
	MOVW R16,R26
	__PUTWSR 20,21,8
	LDI  R30,LOW(0)
	STD  Y+10,R30
	STD  Y+10+1,R30
	MOVW R26,R28
	ADIW R26,12
	__ADDW2R15
	LD   R30,X+
	LD   R31,X+
	ST   -Y,R31
	ST   -Y,R30
	ST   -Y,R17
	ST   -Y,R16
	LDI  R30,LOW(_put_buff_G100)
	LDI  R31,HIGH(_put_buff_G100)
	ST   -Y,R31
	ST   -Y,R30
	MOVW R26,R28
	ADIW R26,12
	RCALL __print_G100
	MOVW R18,R30
	LDD  R26,Y+8
	LDD  R27,Y+8+1
	LDI  R30,LOW(0)
	ST   X,R30
	MOVW R30,R18
_0x2060001:
	RCALL __LOADLOCR6
	ADIW R28,12
	POP  R15
	RET
; .FEND

	.CSEG

	.CSEG
_strlen:
; .FSTART _strlen
	ST   -Y,R27
	ST   -Y,R26
    ld   r26,y+
    ld   r27,y+
    clr  r30
    clr  r31
strlen0:
    ld   r22,x+
    tst  r22
    breq strlen1
    adiw r30,1
    rjmp strlen0
strlen1:
    ret
; .FEND
_strlenf:
; .FSTART _strlenf
	ST   -Y,R27
	ST   -Y,R26
    clr  r26
    clr  r27
    ld   r30,y+
    ld   r31,y+
strlenf0:
	lpm  r0,z+
    tst  r0
    breq strlenf1
    adiw r26,1
    rjmp strlenf0
strlenf1:
    movw r30,r26
    ret
; .FEND

	.DSEG
_cursor:
	.BYTE 0x1
_cuadrante_actual:
	.BYTE 0x1
_fila_actual:
	.BYTE 0x1
_valor_humedad:
	.BYTE 0x2
_buffer_lcd:
	.BYTE 0x10
_buffer_uart:
	.BYTE 0xC

	.CSEG
;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:17 WORDS
SUBOPT_0x0:
	LDI  R26,LOW(2)
	LDI  R27,0
	RCALL _delay_ms
	MOV  R30,R17
	ANDI R30,LOW(0xF0)
	MOV  R16,R30
	SWAP R16
	ANDI R16,0xF
	MOV  R26,R16
	RCALL _SendDataBitsLCD
	RCALL _PulseEn
	MOV  R30,R17
	ANDI R30,LOW(0xF)
	MOV  R16,R30
	MOV  R26,R16
	RCALL _SendDataBitsLCD
	LDI  R26,LOW(2)
	LDI  R27,0
	RCALL _delay_ms
	RJMP _PulseEn

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:1 WORDS
SUBOPT_0x1:
	RCALL __SAVELOCR3
	__PUTW2R 17,18
	LDI  R16,LOW(0)
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:2 WORDS
SUBOPT_0x2:
	MOV  R30,R16
	SUBI R16,-1
	LDI  R31,0
	ADD  R30,R17
	ADC  R31,R18
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:1 WORDS
SUBOPT_0x3:
	ST   -Y,R17
	ST   -Y,R16
	MOV  R16,R26
	LDD  R17,Y+2
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:4 WORDS
SUBOPT_0x4:
	CLR  R31
	CLR  R22
	CLR  R23
	RCALL __PUTPARD1
	LDI  R24,4
	RCALL _sprintf
	ADIW R28,8
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:2 WORDS
SUBOPT_0x5:
	RCALL _frenar
	SBI  0x8,1
	CBI  0x8,2
	SBI  0x5,0
	CBI  0x5,1
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 5 TIMES, CODE SIZE REDUCTION:10 WORDS
SUBOPT_0x6:
	LDI  R30,LOW(0)
	ST   -Y,R30
	LDI  R26,LOW(0)
	RJMP _MoveCursor

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:4 WORDS
SUBOPT_0x7:
	LDI  R26,LOW(800)
	LDI  R27,HIGH(800)
	RCALL _delay_ms
	RCALL _avanzar
	LDI  R26,LOW(1200)
	LDI  R27,HIGH(1200)
	RJMP _delay_ms

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:2 WORDS
SUBOPT_0x8:
	RCALL _StringLCD
	LDI  R30,LOW(0)
	ST   -Y,R30
	LDI  R26,LOW(1)
	RJMP _MoveCursor

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:1 WORDS
SUBOPT_0x9:
	RCALL _StringLCD
	LDS  R30,_cuadrante_actual
	ST   -Y,R30
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:1 WORDS
SUBOPT_0xA:
	ADIW R26,4
	__GETW1P
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:2 WORDS
SUBOPT_0xB:
	LD   R30,X+
	LD   R31,X+
	ADIW R30,1
	ST   -X,R31
	ST   -X,R30
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 5 TIMES, CODE SIZE REDUCTION:18 WORDS
SUBOPT_0xC:
	ST   -Y,R19
	LDD  R26,Y+13
	LDD  R27,Y+13+1
	LDD  R30,Y+15
	LDD  R31,Y+15+1
	ICALL
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 5 TIMES, CODE SIZE REDUCTION:14 WORDS
SUBOPT_0xD:
	LDD  R30,Y+16
	LDD  R31,Y+16+1
	SBIW R30,4
	STD  Y+16,R30
	STD  Y+16+1,R31
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 3 TIMES, CODE SIZE REDUCTION:6 WORDS
SUBOPT_0xE:
	LDD  R26,Y+13
	LDD  R27,Y+13+1
	LDD  R30,Y+15
	LDD  R31,Y+15+1
	ICALL
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:6 WORDS
SUBOPT_0xF:
	LDD  R26,Y+16
	LDD  R27,Y+16+1
	ADIW R26,4
	LD   R30,X+
	LD   R31,X+
	STD  Y+6,R30
	STD  Y+6+1,R31
	LDD  R26,Y+6
	LDD  R27,Y+6+1
	RET

;RUNTIME LIBRARY

	.CSEG
__SAVELOCR6:
	ST   -Y,R21
__SAVELOCR5:
	ST   -Y,R20
__SAVELOCR4:
	ST   -Y,R19
__SAVELOCR3:
	ST   -Y,R18
__SAVELOCR2:
	ST   -Y,R17
	ST   -Y,R16
	RET

__LOADLOCR6:
	LDD  R21,Y+5
__LOADLOCR5:
	LDD  R20,Y+4
__LOADLOCR4:
	LDD  R19,Y+3
__LOADLOCR3:
	LDD  R18,Y+2
__LOADLOCR2:
	LDD  R17,Y+1
	LD   R16,Y
	RET

__INITLOCB:
__INITLOCW:
	PUSH R26
	PUSH R27
	MOVW R26,R22
	ADD  R26,R28
	ADC  R27,R29
__INITLOC0:
	LPM  R0,Z+
	ST   X+,R0
	DEC  R24
	BRNE __INITLOC0
	POP  R27
	POP  R26
	RET

__ANEGW1:
	NEG  R31
	NEG  R30
	SBCI R31,0
	RET

__DIVW21U:
	CLR  R0
	CLR  R1
	LDI  R25,16
__DIVW21U1:
	LSL  R26
	ROL  R27
	ROL  R0
	ROL  R1
	SUB  R0,R30
	SBC  R1,R31
	BRCC __DIVW21U2
	ADD  R0,R30
	ADC  R1,R31
	RJMP __DIVW21U3
__DIVW21U2:
	SBR  R26,1
__DIVW21U3:
	DEC  R25
	BRNE __DIVW21U1
	MOVW R30,R26
	MOVW R26,R0
	RET

__MODW21:
	CLT
	SBRS R27,7
	RJMP __MODW211
	NEG  R27
	NEG  R26
	SBCI R27,0
	SET
__MODW211:
	SBRC R31,7
	RCALL __ANEGW1
	RCALL __DIVW21U
	MOVW R30,R26
	BRTC __MODW212
	RCALL __ANEGW1
__MODW212:
	RET

__GETW1PF:
	LPM  R0,Z+
	LPM  R31,Z
	MOV  R30,R0
	RET

__PUTPARD1:
	ST   -Y,R23
	ST   -Y,R22
	ST   -Y,R31
	ST   -Y,R30
	RET

_delay_ms:
	adiw r26,0
	breq __delay_ms1
__delay_ms0:
	wdr
	__DELAY_USW 0xFA
	sbiw r26,1
	brne __delay_ms0
__delay_ms1:
	ret

;END OF CODE MARKER
__END_OF_CODE:
