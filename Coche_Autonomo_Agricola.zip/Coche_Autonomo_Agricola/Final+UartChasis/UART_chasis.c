/*
 * UARTChaisis.c
 *
 * Created: 03/06/2026 04:37:01 p. m.
 * Author: Valeria Escalante
 *
 * Comunicaci�n con Raspberry Pi:
 *   - UART a 9600 baudios, pin TX (PD1) ? RX de la Raspberry Pi
 *   - Protocolo: "C[cuadrante][estado]\n"
 *     Ejemplo: "C05S\n" = Cuadrante 5, Seco (necesita riego)
 *              "C12H\n" = Cuadrante 12, H�medo (OK)
 *              "CSTART\n"  = Inicio de ciclo
 *              "CFIN\n"    = Fin de mapeo completo
 */

#asm
    .equ __lcd_port=0x0B
    .equ __lcd_RS=2
    .equ __lcd_EN=3
    .equ __lcd_D4=4
    .equ __lcd_D5=5
    .equ __lcd_D6=6
    .equ __lcd_D7=7
#endasm

#include <mega328p.h>
#include <display.h>
#include <stdio.h>
#include <delay.h>

// --- CONFIGURACI�N DE TIEMPOS Y UMBRALES ---
#define TIEMPO_10CM    1200  // Recuerda calibrarlo
#define TIEMPO_GIRO_90 800   // Recuerda calibrarlo
#define UMBRAL_SECO    600   // L�mite para detectar tierra seca (0-1023)

// Configuraci�n de Voltaje de Referencia para el ADC
#define ADC_VREF_TYPE ((0<<REFS1) | (1<<REFS0) | (0<<ADLAR))

// Configuraci�n de UART a 9600 baudios con reloj de 1 MHz
// UBRR = (F_CPU / (16 * BAUD)) - 1 = (1000000 / (16 * 9600)) - 1 � 5
#define UART_BAUD_RATE  9600
#define UART_UBRR_VAL   5

// --- VARIABLES DE CONTROL ---
unsigned char cuadrante_actual = 1;
unsigned char fila_actual = 1;
unsigned int  valor_humedad = 0;
char buffer_lcd[16];
char buffer_uart[12];   // Buffer para armar el mensaje serial


// ============================================================
// --- FUNCIONES UART ---
// ============================================================

// Inicializa la UART a 9600 baudios
void uart_init(void)
{
    // Configura el baud rate (registro de 16 bits)
    UBRR0H = (unsigned char)(UART_UBRR_VAL >> 8);
    UBRR0L = (unsigned char)(UART_UBRR_VAL);

    // Habilita el transmisor (TX). No se necesita receptor por ahora.
    UCSR0B = (1<<TXEN0);

    // Formato de frame: 8 bits de datos, 1 bit de stop, sin paridad
    UCSR0C = (1<<UCSZ01) | (1<<UCSZ00);
}

// Env�a un solo byte por UART
void uart_send_byte(unsigned char data)
{
    // Espera a que el buffer de transmisi�n est� vac�o
    while (!(UCSR0A & (1<<UDRE0)));
    UDR0 = data;
}

// Env�a una cadena de texto por UART (termina en '\0')
void uart_send_string(char *str)
{
    while (*str)
    {
        uart_send_byte(*str);
        str++;
    }
}

// Env�a el estado de un cuadrante a la Raspberry Pi
// Formato: "C[##][H/S]\n"  Ejemplo: "C05S\n", "C36H\n"
void uart_enviar_estado(unsigned char cuadrante, unsigned char humedo)
{
    // Construye el mensaje con sprintf y lo env�a
    sprintf(buffer_uart, "C%02dX\n", cuadrante);
    // Reemplaza la 'X' con el estado real
    buffer_uart[3] = humedo ? 'H' : 'S';
    uart_send_string(buffer_uart);
}


// ============================================================
// --- LECTURA DEL SENSOR DE HUMEDAD (Pin PC0 / A0) ---
// La funci�n devuelve un entero y recibe adc_input que es ADC0
// ============================================================

unsigned int read_adc(unsigned char adc_input)
{
    ADMUX = adc_input | ADC_VREF_TYPE;  // Qu� pin leer y qu� voltaje usar
    delay_us(10);                        // Pausa para estabilizar
    ADCSRA |= (1<<ADSC);                 // Empieza a procesar
    while ((ADCSRA & (1<<ADIF))==0);     // Espera hasta que est� procesado
    ADCSRA |= (1<<ADIF);                 // Listo para la siguiente lectura
    return ADCW;                         // Devuelve resoluci�n completa de 10 bits
}


// ============================================================
// --- CONTROL DE SERVO POR SOFTWARE (Pin PB4) ---
// El servo recibe un pulso repetido cada 20 ms
// ============================================================

void servo_arriba(void)
{
    unsigned char i;
    for(i=0; i<40; i++)
    {
        // Pulso de 1ms = 0 grados
        PORTB.4 = 1;
        delay_us(1000);  // Pulso de 1ms
        PORTB.4 = 0;
        delay_us(19000); // Completa el periodo de 20ms
    }
}

void servo_abajo(void)
{
    unsigned char i;
    for(i=0; i<40; i++)
    {
        // Pulso de 2ms = 180 grados
        PORTB.4 = 1;
        delay_us(2000);  // Pulso de 2ms
        PORTB.4 = 0;
        delay_us(18000); // Completa el periodo de 20ms
    }
}


// ============================================================
// --- FUNCIONES DE MOVIMIENTO (PORTC y PORTB) ---
// ============================================================

void frenar(void)
{
    // Apaga Puente H Delantero (PORTC)
    PORTC.1 = 0; PORTC.2 = 0;
    PORTC.3 = 0; PORTC.4 = 0;

    // Apaga Puente H Trasero (PORTB y PC5)
    PORTB.0 = 0; PORTB.1 = 0;
    PORTB.2 = 0; PORTC.5 = 0;
}

void avanzar(void)
{
    frenar();
    // Lado Izquierdo Adelante (Delantero y Trasero)
    PORTC.1 = 1; PORTC.2 = 0;
    PORTB.0 = 1; PORTB.1 = 0;

    // Lado Derecho Adelante (Delantero y Trasero)
    PORTC.3 = 1; PORTC.4 = 0;
    PORTB.2 = 1; PORTC.5 = 0;
}

void girar_derecha(void)
{
    frenar();
    // Lado Izquierdo Adelante
    PORTC.1 = 1; PORTC.2 = 0;
    PORTB.0 = 1; PORTB.1 = 0;

    // Lado Derecho Atr�s (Giro tipo tanque)
    PORTC.3 = 0; PORTC.4 = 1;
    PORTB.2 = 0; PORTC.5 = 1;
}

void girar_izquierda(void)
{
    frenar();
    // Lado Izquierdo Atr�s
    PORTC.1 = 0; PORTC.2 = 1;
    PORTB.0 = 0; PORTB.1 = 1;

    // Lado Derecho Adelante
    PORTC.3 = 1; PORTC.4 = 0;
    PORTB.2 = 1; PORTC.5 = 0;
}


// ============================================================
// --- MANIOBRA DE VUELTA EN U ---
// ============================================================

void realizar_giro_en_u(void)
{
    MoveCursor(0,0);
    StringLCD("GIRANDO EN U... ");

    if (fila_actual % 2 != 0)
    {
        // Filas impares: gira a la derecha
        girar_derecha();   delay_ms(TIEMPO_GIRO_90);
        avanzar();         delay_ms(TIEMPO_10CM);
        girar_derecha();   delay_ms(TIEMPO_GIRO_90);
    }
    else
    {
        // Filas pares: gira a la izquierda
        girar_izquierda(); delay_ms(TIEMPO_GIRO_90);
        avanzar();         delay_ms(TIEMPO_10CM);
        girar_izquierda(); delay_ms(TIEMPO_GIRO_90);
    }
    frenar();
    delay_ms(500);
}


// ============================================================
// --- PROGRAMA PRINCIPAL ---
// ============================================================

void main(void)
{
    // --- INICIALIZACI�N DE ADC PARA RELOJ DE 1 MHz ---
    // Prescaler en 8 (1 MHz / 8 = 125 kHz de frecuencia de muestreo)
    ADCSRA = (1<<ADEN)  | (0<<ADSC)  | (0<<ADATE) | (0<<ADIF) |
             (0<<ADIE)  | (0<<ADPS2) | (1<<ADPS1) | (1<<ADPS0);
    ADCSRB = (0<<ADTS2) | (0<<ADTS1) | (0<<ADTS0);
    DIDR0  = (1<<ADC0D); // Desactiva entrada digital en A0 para reducir ruido anal�gico

    // --- INICIALIZACI�N DE UART ---
    uart_init();

    // --- CONFIGURACI�N DE SALIDAS DIGITALES ---
    SetupLCD();

    // Pines Puente H Delantero (Salidas)
    DDRC.1 = 1; DDRC.2 = 1;
    DDRC.3 = 1; DDRC.4 = 1;

    // Pines Puente H Trasero (Salidas)
    DDRB.0 = 1; DDRB.1 = 1;
    DDRB.2 = 1; DDRC.5 = 1;

    // Pin del Servo (Salida)
    DDRB.4 = 1;

    // Pin TX de UART ya es salida por hardware al habilitar TXEN0
    // pero se configura expl�citamente por claridad
    DDRD.1 = 1;

    frenar();
    servo_arriba(); // Iniciar con el brazo del sensor arriba

    MoveCursor(0,0);
    StringLCD("SISTEMA LISTO   ");
    delay_ms(3000); // 3 segundos para colocar el carro en el suelo

    // Notifica a la Raspberry Pi que el ciclo va a comenzar
    uart_send_string("CSTART\n");

    while (1)
    {
        if (cuadrante_actual <= 36)
        {
            // 1. Desplegar cuadrante actual e iniciar avance
            MoveCursor(0,0);
            StringLCD("AVANZANDO...    ");
            MoveCursor(0,1);
            sprintf(buffer_lcd, "Cuadrante: %2d   ", cuadrante_actual);
            StringLCDVar(buffer_lcd);

            avanzar();
            delay_ms(TIEMPO_10CM);
            frenar();

            // 2. Proceso mec�nico de medici�n
            MoveCursor(0,0);
            StringLCD("MIDIENDO TIERRA ");

            servo_abajo();          // Introduce el sensor en la tierra
            delay_ms(500);          // Pausa para estabilizaci�n f�sica

            valor_humedad = read_adc(0); // Lectura del pin A0

            // 3. Analizar datos del suelo y enviar resultado
            MoveCursor(0,1);
            if (valor_humedad > UMBRAL_SECO)
            {
                // Tierra seca: avisa en pantalla y notifica a la Raspberry Pi
                StringLCD("SECO - REGAR!   ");
                uart_enviar_estado(cuadrante_actual, 0); // 0 = Seco
            }
            else
            {
                // Tierra h�meda: confirma en pantalla y notifica a la Raspberry Pi
                StringLCD("HUMEDO - OK     ");
                uart_enviar_estado(cuadrante_actual, 1); // 1 = H�medo
            }

            delay_ms(2000); // Mantener el mensaje en pantalla por 2 segundos

            servo_arriba(); // Retraer sensor antes de reiniciar marcha

            // 4. Verificaci�n de final de fila (M�ltiplos de 6)
            if (cuadrante_actual % 6 == 0)
            {
                if (cuadrante_actual < 36)
                {
                    realizar_giro_en_u();
                    fila_actual++;
                }
            }

            cuadrante_actual++;
        }
        else
        {
            // --- FIN DE LA MATRIZ DE RECORRIDO ---
            frenar();

            // Notifica a la Raspberry Pi que el mapeo termin�
            uart_send_string("CFIN\n");

            MoveCursor(0,0);
            StringLCD("MAPEO COMPLETO  ");
            MoveCursor(0,1);
            StringLCD("FIN DEL VIAJE   ");
            while(1); // Bloqueo de seguridad final
        }
    }
}