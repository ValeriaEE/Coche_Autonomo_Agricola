/*
 * Chasis.c
 *
 * Created: 03/06/2026 11:38:13 a. m.
 * Author: Valeria Escalante
 */  
 
 
#asm
    .equ __lcd_port=0x0B
    .equ __lcd_RS=2
    .equ __lcd_EN=3
    .equ __lcd_D4=4
    .equ __lcd_D5=5
    .equ __lcd_D6=6
    .equ __lcd_D7=7
#endasm

#include <mega328p.h>
#include <display.h>
#include <stdio.h>  
#include <delay.h>  

// --- CONFIGURACI�N DE TIEMPOS (Calibraci�n) ---
#define TIEMPO_10CM    1200      //Se tiene que cambiar depende de como se mueva 
#define TIEMPO_GIRO_90 800   

// --- VARIABLES DE CONTROL ---
unsigned char cuadrante_actual = 1;
unsigned char fila_actual = 1;
char buffer_lcd[16];         

// --- FUNCIONES DE MOVIMIENTO (PORTC y PORTB) ---
void frenar(void)
{
    // Apaga Puente H Delantero (PORTC)
    PORTC.1 = 0; PORTC.2 = 0; 
    PORTC.3 = 0; PORTC.4 = 0; 
    
    // Apaga Puente H Trasero (PORTB)
    PORTB.0 = 0; PORTB.1 = 0; 
    PORTB.2 = 0; PORTC.5 = 0; 
}

void avanzar(void)
{
    frenar();  
    
    // Prende Puente H Delantero (PORTC)
    PORTC.1 = 1; PORTC.2 = 0; 
    PORTC.3 = 1; PORTC.4 = 0; 
    
    // Prende Puente H Trasero (PORTB)
    PORTB.0 = 1; PORTB.1 = 0; 
    PORTB.2 = 1; PORTC.5 = 0;  
    
}

void girar_derecha(void)
{
    frenar();
    // Lado Izquierdo Adelante
    PORTC.1 = 1; PORTC.2 = 0;
    PORTB.0 = 1; PORTB.1 = 0;
    
    // Lado Derecho Atr�s (Giro tipo tanque)
    PORTC.3 = 0; PORTC.4 = 1;
    PORTB.2 = 0; PORTC.5 = 1;
}

void girar_izquierda(void)
{
    frenar();
    // Lado Izquierdo Atr�s
    PORTC.1 = 0; PORTC.2 = 1;
    PORTB.0 = 0; PORTB.1 = 1;
    
    // Lado Derecho Adelante
    PORTC.3 = 1; PORTC.4 = 0;
    PORTB.2 = 1; PORTC.5 = 0;
}

// --- MANIOBRA DE VUELTA EN U ---
void realizar_giro_en_u(void)
{
    MoveCursor(0,0);
    StringLCD("GIRANDO EN U... ");
    
    if (fila_actual % 2 != 0) 
    {
        girar_derecha();   
        delay_ms(TIEMPO_GIRO_90);
        avanzar();        
        delay_ms(TIEMPO_10CM);
        girar_derecha();   
        delay_ms(TIEMPO_GIRO_90);
    } 
    else 
    {
        girar_izquierda(); 
        delay_ms(TIEMPO_GIRO_90);
        avanzar();         
        delay_ms(TIEMPO_10CM);
        girar_izquierda(); 
        delay_ms(TIEMPO_GIRO_90);
    }
    frenar();
    delay_ms(500); 
}

void main(void)
{
    // --- INICIALIZACIONES ---
    SetupLCD();
    
    // Configurar pines del Puente H Delantero como salidas (PORTC)
    DDRC.1 = 1; DDRC.2 = 1; 
    DDRC.3 = 1; DDRC.4 = 1; 
    
    // Configurar pines del Puente H Trasero como salidas (PORTB)
    DDRB.0 = 1; DDRB.1 = 1; 
    DDRB.2 = 1; DDRC.5 = 1; 
    
    frenar();
    
    MoveCursor(0,0);
    StringLCD("SISTEMA LISTO   ");
    delay_ms(3000); 

    while (1)
    {
        if (cuadrante_actual <= 36)
        {
            MoveCursor(0,0);
            StringLCD("AVANZANDO...    ");
            MoveCursor(0,1);
            sprintf(buffer_lcd, "Cuadrante: %2d   ", cuadrante_actual);
            StringLCDVar(buffer_lcd);
            
            avanzar();
            delay_ms(TIEMPO_10CM);
            frenar();
            
            MoveCursor(0,0);
            StringLCD("MIDIENDO TIERRA ");
            delay_ms(2000); 
            
            if (cuadrante_actual % 6 == 0)
            {
                if (cuadrante_actual < 36)
                {
                    realizar_giro_en_u();
                    fila_actual++; 
                }
            }
            
            cuadrante_actual++; 
        }
        else
        {
            frenar();
            MoveCursor(0,0);
            StringLCD("MAPEO COMPLETO  ");
            MoveCursor(0,1);
            StringLCD("FIN DEL VIAJE   ");
            while(1); 
        }
    }
}